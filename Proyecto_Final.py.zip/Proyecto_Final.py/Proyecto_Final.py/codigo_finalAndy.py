# Función que pregunta la Cantidad Total de Equipos del Torneo
def total_equipos():
    cant_equipos = int(input(f"¿Cuántos equipos jugaron?: "))
    print ("\n")
    return cant_equipos

# Nombre de cada Equipo del Torneo
def nombres_equipos(cant_equipos):
    lista_equipos = []
    i = 0
    while i < cant_equipos:
        nombre_equipo = str(input(f"Cuál es el nombre del equipo #{i+1}: "))
        lista_equipos.append(nombre_equipo)
        i += 1
    return lista_equipos


# Función que almacena la cantidad de partidos jugados en total
def total_partidos():
    n_total_partidos = int(input("\n¿Cuántos partidos se jugaron en total?: "))
    print ("\n")
    return n_total_partidos

#Esta función recibe la cantidad total de partidos y la lista de equipos como argumentos. Luego, solicita al usuario ingresar los resultados de cada partido, incluyendo los nombres de los equipos y los puntos obtenidos. Los puntos totales se almacenan en un diccionario llamado puntos_totales, donde cada equipo se representa como una clave y se le asigna su puntaje total. Además, se registran los resultados de cada partido en una lista llamada resultados. Finalmente, se devuelven el diccionario de puntos totales y la lista de resultados.
# Función que almacena los Resultados de Cada Partido
def resultados_partidos(n_total_partidos, lista_equipos):
    puntos_totales = {equipo: 0 for equipo in lista_equipos} # Inicializar los puntos de cada equipo en 0 
    new_var = resultados = []
    new_var
    while i < n_total_partidos:
        print(f"PARTIDO #{i+1}")
        equipo_1 = str(input(f"Cuál es el nombre del Equipo 1: "))
        while equipo_1 not in lista_equipos:
            print("El nombre del equipo no es válido. Por favor, ingrese un nombre de equipo válido.")
            equipo_1 = str(input(f"Cuál es el nombre del Equipo 1: "))
        puntos_equipo_1 = int(input(f"¿Cuántos puntos obtuvo {equipo_1}?: "))
        puntos_totales[equipo_1] += puntos_equipo_1 # agregar puntos del equipo 1
        snitch_1_atrapada = False
        snitch_1 = str(input("¿Atrapó la Snitch el Equipo 1? (S/N): "))
        if snitch_1.upper() == "S":
            puntos_totales[equipo_1] += 30 # sumar 30 puntos si atrapó la snitch
            snitch_1_atrapada = True
        
        equipo_2 = str(input(f"Cuál es el nombre del Equipo 2: "))
        while equipo_2 not in lista_equipos:
            print("El nombre del equipo no es válido. Por favor, ingrese un nombre de equipo válido.")
            equipo_2 = str(input(f"Cuál es el nombre del Equipo 2: "))
        puntos_equipo_2 = int(input(f"¿Cuántos puntos obtuvo {equipo_2}?: \n"))
        puntos_totales[equipo_2] += puntos_equipo_2 # agregar puntos del equipo 2
        if not snitch_1_atrapada: # si el equipo 1 no atrapó la snitch, automáticamente se asigna al equipo 2
            puntos_totales[equipo_2] += 30 # sumar 30 puntos si atrapó la snitch del equipo 2
        
        # agregar resultados a la lista
        resultados.append((equipo_1, equipo_2, puntos_equipo_1, puntos_equipo_2))
        
        i += 1

    return puntos_totales, resultados

#Esta función recibe la lista de resultados y la lista de equipos como argumentos. Crea un diccionario llamado puntajes para realizar un seguimiento del puntaje de cada equipo en el torneo. Luego, itera sobre los resultados de cada partido y actualiza los puntajes de los equipos correspondientes. También se tiene en cuenta si algún equipo atrapó la snitch durante el partido, lo cual otorga puntos adicionales. Finalmente, se calcula el puntaje total de cada equipo en función del número de partidos jugados y el número de oponentes enfrentados. Los puntajes totales se almacenan en el diccionario puntajes. La función devuelve este diccionario.
# Función que construye el reporte de resultados de los juegos para cada equipo
# y calcula el puntaje total de cada equipo en el torneo
# y llena los arreglos Resultados y Puntaje Total
def puntaje_total(resultados, equipos):
    import math
    puntajes = {equipo: {"puntos": 0, "partidos": 0, "oponentes": set()} for equipo in equipos}
    
    for partido in resultados:
        equipo_1, equipo_2, puntos_equipo_1, puntos_equipo_2 = partido
        puntajes[equipo_1]["puntos"] += puntos_equipo_1
        puntajes[equipo_1]["partidos"] += 1
        puntajes[equipo_1]["oponentes"].add(equipo_2)
        
        puntajes[equipo_2]["puntos"] += puntos_equipo_2
        puntajes[equipo_2]["partidos"] += 1
        puntajes[equipo_2]["oponentes"].add(equipo_1)
        
        # si el equipo 1 atrapó la snitch
        if puntos_equipo_1 > puntos_equipo_2 + 30:
            puntajes[equipo_1]["puntos"] += 30
        
        # si el equipo 2 atrapó la snitch
        elif puntos_equipo_2 > puntos_equipo_1 + 30:
            puntajes[equipo_2]["puntos"] += 30
    
    for equipo, puntaje in puntajes.items():
        # puntaje por número de partidos
        if puntaje["partidos"] >= 5:
            puntaje_por_n_juegos = 1
        else:
            puntaje_por_n_juegos = math.sqrt(puntaje["partidos"]) / 2.25
        
        # puntaje por número de oponentes
        cantidad_oponentes = len(puntaje["oponentes"])
        if cantidad_oponentes == 1:
            puntaje_por_n_oponentes = 0.33
        elif cantidad_oponentes == 2:
            puntaje_por_n_oponentes = 0.66
        else:
            puntaje_por_n_oponentes = 1
        
        puntajes[equipo]["puntos_totales"] = puntaje["puntos"] + puntaje_por_n_juegos + puntaje_por_n_oponentes
        
    return puntajes


# Función que calcula el promedio de oponentes diferentes de cada equipo
def promedio_oponentes_diferentes(resultados, equipos):
    oponentes = {equipo: set() for equipo in equipos}
    for partido in resultados:
        equipo_1, equipo_2, _, _ = partido
        oponentes[equipo_1].add(equipo_2)
        oponentes[equipo_2].add(equipo_1)
    
    total_oponentes = sum(len(oponentes[equipo]) for equipo in equipos)
    promedio_oponentes = total_oponentes / len(equipos)
    return promedio_oponentes


# Función que calcula el nombre del equipo que ha jugado más partidos en todo el torneo
def equipo_mas_jugado(resultados):
    equipos = {}
    for resultado in resultados:
        equipo_1, equipo_2, puntos_equipo_1, puntos_equipo_2 = resultado
        if equipo_1 in equipos:
            equipos[equipo_1] += 1
        else:
            equipos[equipo_1] = 1
        if equipo_2 in equipos:
            equipos[equipo_2] += 1
        else:
            equipos[equipo_2] = 1
    equipo_mas_jugado = max(equipos, key=equipos.get)
    return equipo_mas_jugado


# Función que calcula el nombre del equipo con menor puntaje en todo el torneo
def equipo_menor_puntaje(resultados, equipos):
    import math
    puntajes = {equipo: 0 for equipo in equipos}
    
    for partido in resultados:
        equipo_1, equipo_2, puntos_equipo_1, puntos_equipo_2 = partido
        puntajes[equipo_1] += puntos_equipo_1
        puntajes[equipo_2] += puntos_equipo_2
    
    menor_puntaje = math.inf
    equipo_menor_puntaje = ''
    
    for equipo, puntaje in puntajes.items():
        if puntaje < menor_puntaje:
            menor_puntaje = puntaje
            equipo_menor_puntaje = equipo

    return equipo_menor_puntaje


def equipos_con_cinco_o_mas_partidos(resultados):
    equipos = set()
    for resultado in resultados:
        equipos.add(resultado[0])
        equipos.add(resultado[1])
    equipos_con_cinco_o_mas = []
    hay_equipos_con_cinco_o_mas_partidos = False  # Bandera para indicar si se encontró al menos un equipo
    for equipo in equipos:
        partidos_jugados = sum([1 for resultado in resultados if resultado[0] == equipo or resultado[1] == equipo])
        if partidos_jugados >= 5:
            equipos_con_cinco_o_mas.append(equipo)
            hay_equipos_con_cinco_o_mas_partidos = True  # Se actualiza la bandera
    if hay_equipos_con_cinco_o_mas_partidos:
        return equipos_con_cinco_o_mas


# Función con la ejecución del Menú.
def menu():
    while True:
        print("Sistema de Administración de Datos de Torneos de Quidditch\n")
        print("Para iniciar deberá ingresar la siguiente información del torneo:")
        print("1 - Cantidad de equipos que jugaron")
        print("2 - El nombre de cada equipo participante")
        print("DEBERÁ ejecutar la opción 1 antes para que las otras opciones funcionen\n")
        print("MENU")
        print("1  •  Ingresar datos iniciales")
        print("2  •  Ingresar los datos de cada partido")
        print("3  •  Imprimir los resultados de cada partido")
        print("4  •  Indicar los puntajes totales de cada equipo")
        print("5  •  Mostrar el promedio de oponentes")
        print("6  •  Indicar el equipo con más partidos jugados")
        print("7  •  Indicar el equipo con el puntaje menor")
        print("8  •  Indicar los equipos con 5 o más juegos")
        print("9 •  Salir\n")

        opcion = int(input("Seleccione una opción: "))
        if opcion == 1:
            cant_equipos = total_equipos()
            lista_equipos = nombres_equipos(cant_equipos)
            n_total_partidos = total_partidos()
            opcion = int(input("\nSeleccione una opción: "))
        if opcion == 2:
            try:
                puntos_totales, resultados = resultados_partidos(n_total_partidos, lista_equipos)
                opcion = int(input("\nSeleccione una opción: "))
            except NameError:
                print("Debe ejecutar la opción 1 para poder imprimir los resultados.")
                opcion = int(input("\nSeleccione una opción: "))
        if opcion == 3:
            try:
                print(f"Los puntos totales de cada equipo son: {puntos_totales}")
                print(f"Los resultados de los partidos son: {resultados}")
                opcion = int(input("\nSeleccione una opción: "))
            except NameError:
                print("Debe ejecutar la opción 1 para poder imprimir los resultados.")
                opcion = int(input("\nSeleccione una opción: "))
        if opcion == 4:
            try:
                print(puntaje_total(resultados, lista_equipos))
                opcion = int(input("\nSeleccione una opción: "))
            except NameError:
                print("Debe ejecutar la opción 1 para poder imprimir los resultados.")
                opcion = int(input("\nSeleccione una opción: "))
        if opcion == 5:
            try:
                promedio = (promedio_oponentes_diferentes(resultados, lista_equipos))
                print(f"El promedio es de: {promedio}%")
                opcion = int(input("\nSeleccione una opción: "))
            except NameError:
                print("Debe ejecutar la opción 1 para poder imprimir los resultados.")
                opcion = int(input("\nSeleccione una opción: "))
        if opcion == 6:
            try:
                equipo_con_mas_partidos = (equipo_mas_jugado(resultados))
                print(f"El equipo con más partidos jugados es: {equipo_con_mas_partidos}")
                opcion = int(input("\nSeleccione una opción: "))
            except NameError:
                print("Debe ejecutar la opción 1 para poder imprimir los resultados.")
                opcion = int(input("S\neleccione una opción: "))
        if opcion == 7:
            try:
                equipo_menor = equipo_menor_puntaje(resultados, lista_equipos)
                print(f"El equipo con menor puntaje es: {equipo_menor}")
                opcion = int(input("\nSeleccione una opción: "))
            except NameError:
                print("Debe ejecutar la opción 1 para poder imprimir los resultados.")
                opcion = int(input("Seleccione una opción: "))
        if opcion == 8:
            try:
                equipos_con_mas_partidos = equipos_con_cinco_o_mas_partidos(resultados)
                print(f"Los equipos que han jugado 5 o más partidos son: {equipos_con_mas_partidos}")
                opcion = int(input("\nSeleccione una opción: "))
            except NameError:
                print("Debe ejecutar la opción 1 para poder imprimir los resultados.")
                opcion = int(input("Seleccione una opción: "))
        if opcion == 9:
            break
        else:
            break

menu()