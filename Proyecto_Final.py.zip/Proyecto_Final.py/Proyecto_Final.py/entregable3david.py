import math


# MENU
def menu():
    
    print("----------------------------------------")
    print("")
    print("--------LIGA DE QUIDDITCH--------")
    print("")
    print("----------------Menú de Opciones----------------")
    print('Opciones disponibles:')
    print('1 - Iniciar el programa')
    print('2 - Registrar la información de los arreglos y construir reporte de resultados.')
    print('3 - Imprimir el reporte de resultados.')
    print('4 - Imprimir el puntaje total de cada uno de los equipos.')
    print('5 - Calcular el promedio de oponentes diferentes.')
    print('6 - Imprimir el nombre del equipo que ha jugado más partidos en todo el torneo.')
    print('7 - Imprimir el nombre del equipo que con menor puntaje en todo el torneo.')
    print('8 - Imprimir los nombres de los equipos que han jugado 5 partidos o más.')
    print('9 -Imprimir el nombre de los equipos que tengan más oponentes que el promedio de oponentes de todo el torneo.')
    print('0- Salir')
    opcion = input("Ingrese una opcion: ")
    return opcion



# INICIA LOS ARREGLOS
def inicializarArreglos():
    num_equipos = (input("Ingrese el numero de equipos de la liga: "))

    while not num_equipos.isnumeric():
        num_equipos = (input(("Ha ingresado un valor incorrecto. Por Favor ingrese un numero: ")))
    num_equipos = int(num_equipos)
    for i in range(num_equipos):
        nom_equipo = input(f"Ingrese el nombre del equipo {i+1}: ")
        equipos.append(nom_equipo)
        juegosTotales.append(0)
        num_rivales.append(0)
        resultados.append("")
        puntaje_equipos_partido.append(0)
        puntaje_total.append(0)

# INGRESA INFORMACION DE PARTIDOS
def registrarInformacion(equipos, juegosTotales, num_rivales, puntaje_total): 
    
    num_equipos = len(equipos)
    puntaje_partidos = 0
         
    for i in range(num_equipos):
        
        num_juegos = (input(f"Ingrese el numero de juegos del equipo {equipos[i]}: "))
        while not num_juegos.isnumeric(): # NO SALE EL PROGRAMA HASTA INGRESAR UN VALOR NUMERICO
            num_juegos = (input(f" El valor no es numerico, ingrese el numero de juegos del equipo {equipos[i]}: "))
        num_juegos = int(num_juegos)
        juegosTotales[i] = num_juegos
        num_rival = (input(f"Ingrese el numero de rivales del equipo {equipos[i]}: "))
        while not num_rival.isnumeric(): # NO SALE EL PROGRAMA HASTA INGRESAR UN VALOR NUMERICO
            num_rival = (input(f" El valor no es numerico, ingrese el numero de rivales del equipo {equipos[i]}: "))
        num_rival = int(num_rival)
        num_rivales[i] = num_rival
        resultado = ""
        if(num_juegos >= 5 ):
            ptos_juegos1 = 1
        else:
            ptos_juegos = ((math.sqrt(num_juegos))/(2.25))
            ptos_juegos1 = round(ptos_juegos,3)

        if(num_rival == 1):
            ptos_oponentes = round(1/3,3)
        elif(num_rival == 2):
            ptos_oponentes = round(2/3,3)
        elif(num_rival >= 3):
            ptos_oponentes = 1
        
        for j in range(num_juegos):
            equipo_rival = input(f"Ingrese el nombre del equipo rival del juego numero {j+1} del equipo {equipos[i]}: ")
            marcador_equipo = (input(f"Ingrese el marcador del equipo {equipos[i]}: "))
            while not marcador_equipo.isnumeric(): # NO SALE EL PROGRAMA HASTA INGRESAR UN VALOR NUMERICO
                marcador_equipo = (input(f" El valor no es numerico, Ingrese el marcador del equipo {equipos[i]}: "))
            marcador_equipo = int(marcador_equipo)
            puntaje_partidos += marcador_equipo
            snitch1 = input("Atrapo la snitch?: ") #Responder con si o no
            marcador_contrario = (input(f"Ingrese el marcador del equipo {equipo_rival}: "))
            while not marcador_contrario.isnumeric(): # NO SALE EL PROGRAMA HASTA INGRESAR UN VALOR NUMERICO
                marcador_contrario = (input(f" El valor no es numerico, Ingrese el marcador del equipo {equipo_rival}: "))
            marcador_contrario = int(marcador_contrario)
            snitch2 = input("Atrapo la snitch?: ") #Responder con si o no

            if(snitch1 == "si"):
                marcador_equipo = str(marcador_equipo)+"*"
            elif(snitch2 == "si"):
                marcador_contrario = str(marcador_contrario)+"*"
                
            resultado = resultado + equipos[i] + " vs " + equipo_rival + " = " + str(marcador_equipo)+" - "+str(marcador_contrario) + " -- "
            resultados[i]= resultado
            puntaje_total[i] = puntaje_partidos + ptos_juegos1 + ptos_oponentes    

            if (j+1==num_juegos):
                resultado = ""
                puntaje_partidos = 0


# IMPRIME LISTA DE RESULTADOS    
def imprimirResultados(equipos, resultados):
    print("----------------------------------------")
    print("Los equipos de la liga son los siguientes:")
    print(equipos)
    print("----------------------------------------")
    print("Los resultados de los equipos son los siguientes:")
    print(resultados)
    print("----------------------------------------")

# IMPRIME EL PUNTAJE TOTAL DE LOS EQUIPOS
def imprimirPuntajeTotal(equipos, puntaje_total):
    print("----------------------------------------")
    print("Los equipos de la liga son los siguientes:")
    print(equipos)
    print("----------------------------------------")
    print("El puntaje total de los equipos son los siguientes:")
    print(puntaje_total)
    print("----------------------------------------")
    
# CALCULA EL PROMEDIO DE RIVALES DE LA LIGA
def calcularPromedioRivales(equipos, num_rivales):
    num_equipos = len(equipos)
    total_rivales = sum(num_rivales)
    promedio = round(total_rivales/num_equipos, 3)
    return promedio

# EQUIPO CON MAS PARTIDOS DE LA LIGA
def equipoMasPartidos(juegosTotales,equipos):
    max_juegos = 0
    equipo_max_juegos = ""
    for i in range(len(equipos)):
        if juegosTotales[i] > max_juegos:
            max_juegos = juegosTotales[i]
            equipo_max_juegos = equipos[i]
    print(f"El equipo que ha jugado más partidos en todo el torneo es {equipo_max_juegos}, con {max_juegos} partidos jugados.")

# EQUIPO CON MENOR PUNTAJE DE LA LIGA
def equipoMenorPuntaje(equipos, puntaje_total):
    min_puntaje = min(puntaje_total)
    equipo_menor_puntaje = puntaje_total.index(min_puntaje)
    return equipos[equipo_menor_puntaje]

# EQUIPO CON MAS DE 5 PARTIDOS JUGADOS
def equiposJugados5Partidos(equipos, juegosTotales):
    print("Equipos que han jugado 5 partidos o más:")
    for i in range(len(juegosTotales)):
        if juegosTotales[i] >= 5:
            print(equipos[i])

# IMPRIMIR EQUIPOS CON MAS RIVALES QUE EL PROMEDIO
def imprimirEquiposMasRivales(equipos, num_rivales, promedio):
    print("Equipos con más oponentes que el promedio:")
    for i in range(len(equipos)):
        if num_rivales[i] > promedio:
            print(equipos[i])




#PROGRAMA PRINCIPAL

equipos = []
juegosTotales = []
num_rivales = []
resultados = []
puntaje_total = []
puntaje_equipos_partido = []
num_equipos = 0

while True:
    opcion = menu()
    if opcion == "1":
        inicializarArreglos()
        puntaje_total = [0] * len(equipos)
    elif opcion == "2":
        registrarInformacion(equipos, juegosTotales, num_rivales, puntaje_total)
    elif opcion == "3":
        imprimirResultados(equipos, resultados)
    elif opcion == "4":
        imprimirPuntajeTotal(equipos, puntaje_total)
    elif opcion == "5":
        promedio = calcularPromedioRivales(equipos, num_rivales)
        print("El promedio de oponentes es: ", promedio)
    elif opcion == "6":
        equipo = equipoMasPartidos(juegosTotales, equipos)
    elif opcion == "7":
        equipo = equipoMenorPuntaje(equipos, puntaje_total)
        print(f"El equipo con menor puntaje es {equipo}")
    elif opcion == "8":
        equiposJugados5Partidos(equipos, juegosTotales)
    elif opcion == "9":
        imprimirEquiposMasRivales(equipos, num_rivales, promedio)
    elif opcion == "0":
        print("Cerrando el programa...")
        break
    else:
        print("Opción inválida")









