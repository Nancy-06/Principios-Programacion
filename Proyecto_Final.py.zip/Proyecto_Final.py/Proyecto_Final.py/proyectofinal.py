
def menu():
    print("----------------Menú de Opciones----------------")
    print('Opciones disponibles:')
    print('1 - Iniciar el programa')
    print('2 - Registrar la información de los arreglos.')
    print('3 - Construir el reporte de resultados.')
    print('4 - Imprimir el reporte de resultados.')
    print('5 - Imprimir el puntaje total de cada uno de los equipos.')
    print('6 - Calcular el promedio de oponentes diferentes.')
    print('7 - Imprimir el nombre del equipo que ha jugado más partidos en todo el torneo.')
    print('8 - Imprimir el nombre del equipo que con menor puntaje en todo el torneo.')
    print('9 - Imprimir los nombres de los equipos que han jugado 5 partidos o más.')
    print('10 -Imprimir el nombre de los equipos que tengan más oponentes que el promedio de oponentes de todo el torneo.')
    print('0- Salir')


equipos = []
inum_juegos = []
num_oponentes = []
resultados = []
puntaje_total = []

def iniciarPrograma():
    global nom_equipo, num_juegos
    totalEquipos = int(input("Ingrese el  total de equipos del torneo: "))
    for i in range(totalEquipos):
        nom_equipo = input(f"Ingrese el nombre del equipo {i+1}: ")
        equipos.append(nom_equipo)
        num_juegos.append(0)
        num_oponentes.append(0)
        resultados.append([])
        puntaje_total.append(0)

iniciarPrograma()
print("equipos")
print(equipos)


def registrarInformacion():
    global num_juegos
    for i in range(len(equipos)):
        num_juegos[i] = int(input(f"Ingrese la cantidad de juegos que ha tenido {equipos[i]}: "))
        num_oponentes[i] = int(input(f"Ingrese la cantidad de oponentes que ha tenido {equipos[i]}: "))

registrarInformacion()
print("num_juegos")
print(num_juegos)
print("num_oponentes")
print(num_oponentes)    


def construirReporte():
    global nom_equipo
    juego = 1
    puntaje_total = 0
    mensaje = ""

    for i in range(len(resultados)):
        equipo_rival = input((f"Ingrese el nombre del equipo rival del número de juego {juego}: "))
        juego+=1 
        marcador_equipo = int(input(f"Ingrese el marcador del equipo {nom_equipo[0]}:"))
        puntaje_total += marcador_equipo
        snitch1 = input("Atrapo la snitch?: ") #Responder con si o no
        marcador_contrario = int(input(f"Ingrese el marcador del equipo {equipo_rival[]}: "))
        snitch2 = input("Atrapo la snitch?: ") #Responder con si o no

        if(snitch1 == "si"):
            marcador_equipo = str(marcador_equipo)+"*"
        elif(snitch2 == "si"):
            marcador_contrario = str(marcador_contrario)+"*"

        print("")

        mensaje[i] = mensaje + "\n" + nom_equipo + " vs " + equipo_rival + " = " + str(marcador_equipo)+" - "+str(marcador_contrario)

    return puntaje_total, mensaje

puntaje_total, mensaje = construirReporte()
print(resultados)



       
   

