import math
nombre_equipo = ""
puntaje_partidos = 0
num_juegos = 0
num_oponentes = 0
puntaje_total = 0.0


nombre_equipo = input("Ingrese el nombre del equipo: ")
puntaje_partidos = int(input("Ingrese el puntaje de los partidos:"))
num_juegos = int(input("Ingrese el numero de juegos: "))
num_oponentes = float(input("Ingrese puntaje por numero de oponentes: "))


if num_juegos >= 5:
    ptos_juegos = 1
elif num_juegos <5:
    ptos_juegos = ((math.sqrt(num_juegos))/(2.25))

if num_oponentes == 1:
 ptos_oponentes = 0.33
elif num_oponentes == 2:
     ptos_oponentes = 0.66
elif num_oponentes >=3:
   ptos_oponentes = 1

puntaje_total = puntaje_partidos + ptos_juegos + ptos_oponentes

print("Nombre del equipo: ", nombre_equipo)
print("Puntaje de todos los partidos: ", puntaje_partidos)
print("Número de juegos ejecutados:", num_juegos)
print("Número de oponentes diferentes: ", num_oponentes)

print("El puntaje total del equipo", nombre_equipo,"es:",puntaje_total)
print("------------------------------------------")



      




    
