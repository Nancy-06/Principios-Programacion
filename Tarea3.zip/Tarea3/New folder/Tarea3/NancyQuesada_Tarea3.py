#Dado el número de estudiantes encuestados, el programa debe generar un reporte para el colegio teniendo en cuenta lo siguiente:
# Total de estudiantes que contestaron la encuesta en cada nivel.
# El porcentaje total de estudiantes becados y de estudiantes no becados, en el colegio.
# El monto total mensual y anual otorgado por becas deportivas, y el monto total mensual y anual otorgado por becas académicas. Suponga que las becas se otorgan de Febrero a Diciembre.
# El total de estudiantes que pertenecen a los equipos de baloncesto, natación y ajedrez, y el total de estudiantes que no pertenecen a ningún equipo

i = 1
num_encuestados = 0
academica = 0
deportiva = 0
nivel = 0
nivel_1 = 0
nivel_2 = 0
nivel_3 = 0
nivel_4 = 0
nivel_5 = 0 
equipo = "" 
beca = "" 
tipo_beca = ""
monto_mensual_deport = 0.0
monto_anual_deport = 0.0
monto_mensual_academ = 0.0
monto_anual_academ = 0.0
becados = 0
no_becados = 0
porc_total_bec = 0.0
porc_total_no_bec = 0.0
baloncesto = 0
natacion = 0
ajedrez = 0
ninguno = 0


num_encuestados = int(input("Ingrese el número de estudiantes a encuestar: ")) 
while (i <= num_encuestados):
    nivel = int(input("Favor ingrese el nivel académico: ")) 
    if nivel == 1: 
        nivel_1 += 1
    elif nivel ==2: 
        nivel_2 += 1
    elif nivel == 3: 
        nivel_3 += 1
    elif nivel == 4: 
        nivel_4 += 1
    elif nivel == 5:
        nivel_5 += 1

    beca = (input("Favor indicar si cuenta con beca o no: ")) #Responder con si o no 
    if beca == "si":
        tipo_beca = input("Indique si beca acádemica o deportiva: ") 
        if tipo_beca == "deportiva":
            deportiva += 1                    
        elif tipo_beca == "academica":
            academica +=1                        
            becados += 1
    elif beca == "no":
        no_becados +=1
        
    equipo = input("Favor ingrese el equipo de interés: ") 
    if equipo == "baloncesto":
        baloncesto += 1                   
    elif equipo == "natacion":
        natacion += 1                     
    elif equipo == "ajedrez":
        ajedrez += 1                        
    elif equipo == "ninguno":
        ninguno += 1                        

    i +=1
    
porc_total_bec = (becados * 100) / num_encuestados      
porc_total_no_bec = (no_becados * 100) / num_encuestados  

monto_mensual_deport = 80000 * deportiva                       
monto_anual_deport = monto_mensual_deport * 11               
monto_mensual_academ = 50000 * academica                       
monto_anual_academ = monto_mensual_academ * 11                  

print("Total de estudiantes que contestaron la encuesta por cada nivel: ")
print("Nivel 1: ", nivel_1)
print("Nivel 2: ", nivel_2)
print("Nivel 3: ", nivel_3)
print("Nivel 4: ", nivel_4)
print("Nivel 5: ", nivel_5)
print("El porcentaje total de estudiantes becados es de ", porc_total_bec)
print("El porcentaje total de estudiantes no becados es de ", porc_total_no_bec)
print("El monto total mensual y anual otorgado por becas académicas es de: ", monto_mensual_academ, "y",monto_anual_academ)
print("El monto total mensual y anual otrorgado por becas deportivas es de: ", monto_mensual_deport, "y", monto_anual_deport)
print("El total de estudiantes que pertenecen a los equipos es de: ")
print("Baloncesto: ",baloncesto)
print("Natación: ", natacion)
print("Ajedrez: ",ajedrez)
print("Ninguno: ", ninguno)

