cantidad_encuestas = 0
nivel1 = 0
nivel2 = 0
nivel3 = 0
nivel4 = 0
nivel5 = 0
baloncesto = 0
natacion = 0
ajedrez = 0
ninguno = 0
academica = 0
deportiva = 0
no_beca = 0

cantidad_encuestas = int(input('Ingrese la cantidad de encuestas: '))

for i in range(cantidad_encuestas):
    nivel = input("Ingrese su nivel: ")
    equipo = input("1- Baloncesto, 2- Natación, 3- Ajedrez, 4- Ninguno: ")
    tipo_beca = input("Tiene beca: 1- Académica, 2- Deportiva, 3- Ninguno: ")

    if nivel == '1':
        nivel1 += 1
    elif nivel == '2':
        nivel2 += 1
    elif nivel == '3':
        nivel3 += 1
    elif nivel == '4':
        nivel4 += 1
    elif nivel == '5':
        nivel5 += 1

    if equipo == '1':
        baloncesto += 1
    elif equipo == '2':
        natacion += 1
    elif equipo == '3':
        ajedrez += 1
    elif equipo == '4':
        ninguno += 1
    
    if tipo_beca == '1':
        academica += 1
    elif tipo_beca == '2':
        deportiva += 1
    elif tipo_beca == '3':
        no_beca += 1

becados_porc = (academica + deportiva) * 100 / cantidad_encuestas

print(f'Cantidad de respuestas: {cantidad_encuestas}')
print(f'Porcentaje de estudiantes becados: {(academica + deportiva) * 100 / cantidad_encuestas}%')
print(f'Porcentaje de estudiantes no becados: {(no_beca) * 100 / cantidad_encuestas}%')
print(f'Monto becas deportivas: Mensual: {deportiva * 80000}, anual: {(deportiva * 80000) * 11}')
print(f'Monto becas académicas: Mensual: {academica * 50000}, anual: {(academica * 50000) * 11}')
print(f'Participantes de equipos: Baloncesto: {baloncesto}. Natación: {natacion}. Ajedrez: {ajedrez}. Ninguno: {cantidad_encuestas - baloncesto - natacion - ajedrez}')