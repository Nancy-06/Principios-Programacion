"""
La empresa X desea calcular el pago de la comisión sobre las ventas a un vendedor
de acuerdo con el tipo de vendedor como está en la tabla, imprima el resultado de la comisión.

TIPO   COMISION
A        8%
B        6%
C        4%
D        2%

Realice el proceso para la n cantidad de empleados que tiene la empresa y almacene en una lista cada comisión
obtenida por los empleados y con base en eso imprima el valor total a pagar por concepto de comisiones
de todos los empleados.
"""
listaComisiones = []
#proceso para la n cantidad de empleados
i=0
cantEmpleados = int(input("Ingrese la cantidad de empleados de la empresa: "))
for i in range(cantEmpleados):
    print("Cálculo de comisión para el empleado: ",(i+1)) #esto es opcional, es para que me lo imprima empleado x empleado
    nombre = input("Ingrese el nombre del vendedor: ")
    valorVentas = float(input("Ingrese el valor en ventas: "))
    tipo= input("Ingrese el tipo de empleado (A,B,C,D): ")
    comision = 0.0
    porc= 0.0

#para saber el tipo de empleado agrego condiciones
if tipo == "A":
    porc = 0.08
elif tipo == "B":
    porc = 0.06
elif tipo == "C":
    porc = 0.04
elif tipo == "D":  
    porc = 0.02
else:
    print("El tipo de empleado no existe, ingrese un valor válido")    

#calculo de la comision
comision=valorVentas+(valorVentas*porc)

#lista cada comision obtenida x los empleados

listaComisiones.append(comision)  #la lista se hace debajo del calculo de comisiones porque ya 1 vez teniendo el resultado lo ocupo ir almacenando en la variable listaComisiones
                                    
#IMPRIMIR RESULTADO DE LA COMISION
print(f"Las ventas totales de {nombre} son {valorVentas} y el pago final por concepto del {porc*100} comisión es de {comision}")
 
#imprimir el valor total a pagar por concepto de comisiones de todos los empleados.
suma=0.0
for valor in listaComisiones:
    suma+=valor
promedioVentas=suma/len(listaComisiones) 

print(f"El valor a pagar por concepto de nómina es:{suma}")
print(f"El promedio de ventas es de:{promedioVentas}")
