#Determinar si una persona tiene fiebre. Una persona tiene fiebre si la temperatura es mayor a 37 grados. El programa recibe como información la temperatura de la persona

temperatura = 0.0
temperatura = float(input("Ingrese su temperatura: "))

if temperatura >= 37 :
    print("Usted tiene fiebre")
else:
    print("Usted no tiene fiebre")
