#Costa Rica tiene las fronteras cerradas para todas personas que provienen del exterior debido a la pandemia, salvo aquellas cuya nacionalidad es costarricense. El programa recibe como entrada la nacionalidad de la persona
nacionalidad = ""
nacionalidad = (input("Ingrese su nacionalidad: "))

if nacionalidad == "costarricense":

    print ("Su nacionalidad es permitida")

else:
    print ("Su nacionalidad no es permitida")
    