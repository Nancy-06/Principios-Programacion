golesHugo = 0
golesPaco = 0
golesLuis = 0
equipo1 = ''
equipo2 = ''

golesHugo = int(input('Ingrese la cantidad de goles de Hugo: '))
golesPaco = int(input('Ingrese la cantidad de goles de Paco: '))
golesLuis = int(input('Ingrese la cantidad de goles de Luis: '))

equipo1 = golesHugo
equipo2 = golesPaco + golesLuis
if golesHugo >= equipo2:
    print(f'El equipo ganador es el de Hugo con {equipo1} goles')

else:
    print(f'El equipo ganador es el de Paco y Luis con {equipo2} goles')