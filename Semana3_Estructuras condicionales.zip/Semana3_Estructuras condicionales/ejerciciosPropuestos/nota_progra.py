#Calcule la nota final de un estudiante para un curso de fundamentos de programación. La rúbrica de evaluación del curso determina que hay solamente tres exámenes y que la nota del curso se calcula por medio de
#un promedio simple (la suma de las notas de los tres exámenes dividido entre tres). El estudiante aprueba si el promedio es igual o mayor a 70. 
nota1 = 0.0
nota2 = 0.0
nota3 = 0.0
promedio = 0.0

nota1 = float(input("Favor ingresar la nota1: "))
nota2 = float(input("Favor ingresar la nota2: "))
nota3 = float(input("Favor ingresar la nota3: "))

promedio = nota1 + nota2 + nota3 / 3
if promedio >= 70:
    print ("El promedio es de: ", promedio)

