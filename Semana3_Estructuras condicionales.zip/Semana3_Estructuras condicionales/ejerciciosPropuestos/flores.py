#Una empresa que vende flores sacó una promoción para la última semana de mayo. Si el cliente compra tres flores, le aplica un descuento del 10 %. El programa recibe la cantidad de flores y el precio de cada
# flor. Se debe imprimir el total a pagar.

cant_flores = 0
precio_total_flores = 0.0
descuento = 0.0
total = 0.0

cant_flores = int(input("Ingrese la cantidad de flores compradas: "))
precio_total_flores = int(input("Ingrese el precio total por las flores: "))


if cant_flores == 3:
   total = precio_total_flores - descuento
   print("El total a pagar con descuento es de: ", total)
else:
   total = precio_total_flores
   print("El total a pagar por las flores es de: ", total)


      
