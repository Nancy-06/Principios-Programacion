#Definir si una persona debe pagar impuesto al valor agregado por su consumo mensual de electricidad. El programa recibe el consumo mensual de la persona. Se deduce un impuesto del 13% si el consumo es mayor
# a 200 kWh
consumo_en_kWh = 0
consumo_en_kWh = int(input("Ingrese su consumo en kWh: "))

if consumo_en_kWh >= 200:

    print("Usted debe pagar IVA")

else:
    print("Usted no debe pagar IVA")    












