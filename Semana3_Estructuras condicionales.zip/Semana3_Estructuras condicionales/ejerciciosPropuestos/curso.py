#Determinar si un estudiante ganó o perdió un curso, si pierden el curso todos los estudiantes cuya nota es menor a 70.
nota = 0
nota = int(input("Ingrese la nota del curso: "))

if nota >=70:
    print("Usted gano el curso")

else: 
    print("Usted no gano el curso")

    