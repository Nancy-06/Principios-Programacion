#Felipe es un programador que debe marcar todos lo días la hora de entrada y la hora de salida. Si Felipe trabajó más de ocho horas, hay que pagarle un costo por hora extra que es igual a 1.5 el monto de la
#tarifa por hora. Haga un programa que, recibiendo la tarifa por hora, la hora de entrada y la hora de salida, imprima el total de dinero que Felipe recibió en ese díafrom datetime import datetime
from datetime import datetime
costoHoraextra = 1.5
porcHoraextra = 0.0
tarifaHora = 0.0
horas = 0
totalDinero = 0.0


tarifaHora = float(input('Indique la tarifa por hora: '))
horaEntrada = input('Indique la hora de entrada (HH:MM): ')
horaSalida = input('Indique la hora de salida (HH:MM): ')

# Convertir las horas de entrada y salida a objetos datetime
formatoHora = "%H:%M"
entrada = datetime.strptime(horaEntrada, formatoHora)
salida = datetime.strptime(horaSalida, formatoHora)

# Calcular la cantidad de horas trabajadas
diferencia = salida - entrada
horas = diferencia.total_seconds() / 3600

# Calcular el total de dinero recibido
if horas > 8:
    horasNormales = 8
    horasExtras = horas - 8
    porcHoraextra = tarifaHora * costoHoraextra
    totalDinero = (horasNormales * tarifaHora) + (horasExtras * porcHoraextra)
else:
    totalDinero = horas * tarifaHora

# Imprimir el total de dinero recibido
print(f'El total de dinero recibido por Felipe en ese día es: {totalDinero:.2f}')
