num1 = 0
num2 = 0

num1 = int(input('Indique el primer número: '))
num2 = int(input('Indique el segundo número: '))
# Verificar si num1 es divisible entre num2
if num2 != 0 and num1 % num2 == 0:
    print(f'El primer número {num1} es divisible entre el segundo número {num2}')

else:
    print(f'No es divisible')    