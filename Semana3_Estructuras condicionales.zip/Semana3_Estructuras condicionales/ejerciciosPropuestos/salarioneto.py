#El Gobierno ha decidido que todas aquellas personas que tienen un salario igual a superior a un millón de colones deben pagar un impuesto del 10%. Calcule el salario neto de un trabajador. El sistema recibe 
#el salario del trabajador como entrada.

salario = 0
impuesto = 0.5

salario = int(input("Ingrese su salario: "))

if salario >= 1_000_000:
    impuesto = salario * 0.5
    salario = salario - impuesto

    print("Su salario es de: " , salario)


