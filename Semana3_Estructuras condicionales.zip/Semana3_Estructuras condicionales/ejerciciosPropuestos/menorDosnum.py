#Calcule el menor de dos números

numero1 = 0
numero2 = 0
menor = 0

numero1 = int(input('Ingrese un número: '))
numero2 = int(input('Ingrese otro número: '))

if numero1 < numero2:
    menor = numero1

else:
    menor = numero2

print(f'El menor de los dos números es: ', menor)
