#Determinar si un ciudadano puede votar. Un ciudadano puede votar si ya cuenta con 18 años cumplidos. El programa recibe la edad del ciudadano

edad = 0
edad = int(input("Ingrese su edad: "))

if edad >= 18:
    print ("Usted puede votar")

else:
    print ("Usted no puede votar)")   
