#Una línea aérea pone en promoción los viajes a África. La promoción indica que el costo del tiquete tendrá una rebaja del 15 %. Imprima el costo real del tiquete si el programa recibe el precio original
#del mismo.

costoTiquete = 0.0
rebaja = 0.15
porcRebaja = 0.0
costoReal = 0.0

costoTiquete = int(input('Indique el costo del tiquete: '))
porcRebaja = costoTiquete * rebaja
costoReal = costoTiquete - porcRebaja

print (costoReal)