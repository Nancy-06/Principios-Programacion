#Vilma Picapiedra envía a Pedro a comprar el pan, el jamón, el queso, el tomate y la lechuga para hacer el almuerzo del domingo. Vilma le entregó a Pedro 10 mil colones, y regresó con 2700. Cuando Vilma
# le preguntó cuánto le costó cada cosa, Pedro le contesta que el pan le costó un 15 %, el tomate un 35 %, el queso y el jamón ambos un 20 % y la lechuga un 10%. Haga un programa que calcule el costo en colones
# de cada ingrediente

dineroInicial = 10000
pan = 0.0
jamon = 0.0
queso = 0.0
tomate = 0.0
lechuga = 0.0
vuelto = 2700
porcPan = 0.15
porcQueso = 0.20
porcTomate = 0.35
porcJamon = 0.20
porcLechuga = 0.10

pan = (dineroInicial - vuelto) * porcPan
jamon = (dineroInicial - vuelto) * porcJamon
queso = (dineroInicial - vuelto) * porcQueso
tomate = (dineroInicial - vuelto) * porcTomate
lechuga = (dineroInicial - vuelto) * porcLechuga

print(f'Precio del pan: ', pan)
print(f'Precio del jamón: ', jamon)
print(f'Precio del queso: ', queso)
print(f'Precio del tomate: ', tomate)
print(f'Precio de la lechuga: ', lechuga)