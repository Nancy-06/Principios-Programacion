#El costo de un automóvil nuevo viene dado por la suma total del costo del vehículo, el porcentaje de ganancia del vendedor y de los impuestos. Si el porcentaje del vendedor es de un 10 % y el impuesto del 30%,
#diseñe un algoritmo que permita leer el costo del automóvil e imprimir el costo final para el consumidor

porcVendedor = 0.10
impuesto = 0.30

# Solicitar el costo del automóvil
costoAutomovil = float(input('Ingrese el costo del automóvil: '))

# Calcular el costo final
costoFinal = costoAutomovil * (1 + porcVendedor + impuesto)

# Imprimir el costo final
print(f'El costo final del automóvil para el consumidor es: ', costoFinal)