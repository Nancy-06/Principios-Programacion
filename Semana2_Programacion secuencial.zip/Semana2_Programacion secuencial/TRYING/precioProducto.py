#el precio final siempre es el precio original + el precio * el IVA
tasaImpuesto = 0.13
nombreProducto = '' 
precio = 0.0
precioFinal = 0.0

nombreProducto = input('Ingrese el nombre del producto: ')

precio = float(input('Ingrese el precio del producto: '))

precioFinal = precio + (precio * tasaImpuesto)

print(nombreProducto)
print(precioFinal)
