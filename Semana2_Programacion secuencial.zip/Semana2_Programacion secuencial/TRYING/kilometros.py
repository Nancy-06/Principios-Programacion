#Calcular la cantidad de kilómetros de un viaje realizado en carro. El algoritmo debe recibir el kilometraje del vehículo antes de iniciar el viaje, y el kilometraje del vehículo al terminar el viaje. Se debe imprimir el total de kilómetros del viaje.
cantidadKm = 0
kmInicial = 0
kmFinal = 0
totalKM = 0

kmInicial = int(input('Indique la cantidad de kms iniciales: '))
kmFinal = int(input('Indique la cantidad de kms finales: '))

totalKM = kmFinal - kmInicial

print(totalKM)

