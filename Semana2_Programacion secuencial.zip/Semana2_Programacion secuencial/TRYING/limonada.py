#Hugo, Paco y Luis decidieron vender limonada en el barrio. Decidieron cobrar por cada limonada 10 colones debido a que fabricar cada limonada les cuesta 5.50 colones. Como no todos trabajaron por igual,
#decidieron que las ganancias se iban a repartir de la siguiente forma 30 % para Paco, 30 % para Luis y 40 % para Hugo. Haga un programa que reciba la cantidad total de limonadas que vendieron, e imprima
#cuánto ganó Hugo, cuánto ganó Paco y cuánto ganó Luis.

precioLimonada = 10
subTotal = 0.0
paco = 0.30
luis = 0.30
hugo = 0.40
cantidadTotal = 0.0
gananciaHugo = 0.0
gananciaLuis = 0.0
gananciaPaco = 0.0
costoProduccion = 5.5

cantidadTotal = int(input('Ingrese la cantidad de limonadas vendidas: '))
subTotal = cantidadTotal * (precioLimonada - costoProduccion)
gananciaHugo = subTotal * hugo
gananciaLuis = subTotal * luis
gananciaPaco = subTotal * paco

print(gananciaHugo)
print(gananciaLuis)
print(gananciaPaco)

