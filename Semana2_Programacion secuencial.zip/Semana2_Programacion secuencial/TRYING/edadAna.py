#Encontrar la edad de Ana dentro de diez años, si la edad de Ana es dos veces la edad de Elena. El programa recibe como entrada la edad actual de Elena, y debe imprimir la edad de Ana dentro de diez 
añosedadAna = 0
edadFutura = 0
edadElena = 0
edad = 0

edadElena = int(input('Ingrese la edad de Elena: '))

edadAna = edadElena * 2
edadFutura = edadAna + 10

print(f'La edad futura de Ana es de:' , {edadFutura})
