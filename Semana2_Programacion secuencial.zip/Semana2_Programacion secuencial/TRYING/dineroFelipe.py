#Felipe es un programador que debe marcar todos lo días la hora de entrada y la hora de salida. Haga un programa que, recibiendo la tarifa por hora, imprima el total de dinero que Felipe recibió en ese día 
#y la cantidad de horas que trabajó

from datetime import datetime

tarifaHora = 0
horaEntrada = 0
horaSalida = 0
totalDinero = 0
totalHoras = 0
formatoHora = ''

# Solicitar la tarifa por hora
tarifaHora = float(input('Ingrese la tarifa por hora: '))

# Solicitar la hora de entrada y salida
horaEntrada = input('Ingrese la hora de entrada (HH:MM): ')
horaSalida = input('Ingrese la hora de salida (HH:MM): ')

# Convertir las horas de entrada y salida a objetos datetime
formatoHora = "%H:%M"
entrada = datetime.strptime(horaEntrada, formatoHora)
salida = datetime.strptime(horaSalida, formatoHora)

# Calcular la cantidad de horas trabajadas
diferencia = salida - entrada
totalHoras = diferencia.total_seconds() / 3600

# Calcular el total de dinero recibido
totalDinero = totalHoras * tarifaHora

# Imprimir el total de dinero recibido y la cantidad de horas trabajadas
print(f'Felipe trabajó {totalHoras} horas y recibió un total de {totalDinero} en ese día.')