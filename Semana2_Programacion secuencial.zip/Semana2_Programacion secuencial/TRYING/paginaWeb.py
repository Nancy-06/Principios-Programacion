#Gabriel es un trabajador independiente que cobra 50 dólares por cada página web. Calcule los ingresos del total del mes de Gabriel. El programa recibe la cantidad de páginas web que le contrataron a Gabriel.

costoPagina = 50.00    #a la cantidad en dolares le agrego un 00
ingresos = 0.0
cantPaginas = 0

cantPaginas = int(input('Ingrese la cantidad de páginas web contratadas: '))

ingresos = (costoPagina * cantPaginas)
print (ingresos)


