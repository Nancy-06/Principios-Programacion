#Encontrar la edad de la abuela de Ana a hoy, si es 7 años menor que el abuelo de Ana, y en el año del matrimonio, el abuelo tenía 25 años. El programa recibe como entrada el año del matrimonio.
añosMenor = 7
edadAbuela = 0
edadAbueloantes = 25
añoMatrimonio = 0
añoActual = 2024

añoMatrimonio = int(input('Ingrese el año del matrimonio: '))

edadAbueloactual = (añoActual - añoMatrimonio) + edadAbueloantes
edadAbuela = edadAbueloactual - añosMenor 

print(f'La edad actual de la abuela a hoy es: ', edadAbuela)




