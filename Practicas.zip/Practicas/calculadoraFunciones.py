def sumar(num1_input, num2_input):
    resultado = num1_input+num2_input
    print (f"La suma de {num1_input} + {num2_input}={resultado}")

def restar(num1_input, num2_input):
    resultado = num1_input-num2_input
    print (f"La resta de {num1_input} - {num2_input}={resultado}")


def multiplicar(num1_input, num2_input):
    resultado = num1_input*num2_input
    print (f"La multiplicación de {num1_input} * {num2_input}={resultado}")


def dividir(num1_input, num2_input):
    if (num1_input and num2_input>0):
        resultado = num1_input/num2_input
        print (f"La división de {num1_input} / {num2_input}={resultado}")
    else:
        print ('No se puede dividir por cero')
     
print("----------------Menú----------------")
print('Operaciones disponibles')
print('1 - Suma')
print('2 - Resta')
print('3 - Multiplicación')
print('4 - División')
print('5 - Salir')

opcion_seleccion=0
while (opcion_seleccion!=5):
    num1_input = int(input('Ingrese el primer número: '))
    num2_input = int(input('Ingrese el segundo número: '))
    opcion_seleccion = int(input("Ingrese el número de operación a realizar: "))
    if opcion_seleccion ==1:
        sumar(num1_input,num2_input)
    elif opcion_seleccion ==2:
        restar(num1_input,num2_input)
    elif opcion_seleccion ==3:
        multiplicar(num1_input,num2_input)
    elif opcion_seleccion ==4:
        dividir(num1_input,num2_input)
    elif opcion_seleccion ==5:   
        print('Finalizado') 
    else:
        print('Ha ingresado una opción incorrecta')
             




