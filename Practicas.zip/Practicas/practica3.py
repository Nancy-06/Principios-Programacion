#Crear un programa para conocer si un usuario puede votar o no, el programa recibe el nombre, la edad y si tiene cedula o no. Imprimir en pantalla los datos y que muestre un msj indicando
#si es mayor de edad, de la 3ra edad o menor de edad y también que muestre un msj que solcite renovacion de cedula en caso de ser mayor de edad y no contar con esta.

nombre = input("Favor ingrese su nombre: ")
edad = int(input("Ingrese su edad: "))

if edad >=18:
    print("Usted es mayor de edad.")
elif edad >=60:
    print("Usted es ciudadano de oro")
    cedula = input("Indique si cuenta con cedula: ")#indique si o no
    if cedula == "si":
        print(f"{nombre}, usted puede proceder a votar, favor presentarse con la cédula.")
    else:
        print(f"{nombre}, usted no puede votar, favor dirigirse a hacer la renovacion de su cedula.")

if edad < 18:
    print("Usted es menor de edad y no puede votar.")   
