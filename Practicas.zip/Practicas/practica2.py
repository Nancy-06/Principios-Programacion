#Algoritmo que calcula lo que gana un empleado con base a las horas trabajadas teniendo en cuenta que cada hora se paga a 2000. Adicionalmente se le realiza unos descuentos con respecto a un impuesto de seguridad del 10% sobre su salario.
horasTrabajadas = 0
pagoHora = 2000
descuento = 0.0
aumento = 0.0
salarioTotal = 0.0
#Calcule el salario base
horasTrabajadas = int(input("Ingrese la cantidad de horas laboradas a la semana: "))
salario = horasTrabajadas * pagoHora
print(f"Su salario base es de: {salario}")
 
#Calcule el descuento del 10%
porc_descuento = salario*0.1
print(f"Se le aplicara un descuento del 10% equivalente en colones a: {porc_descuento}")
#Calcule el salario neto con  descuento
salario += salario - porc_descuento    #tamb puede ser salarioTotal = salario - (salario*0.1) o salarioTotal = salario - porc_desc, como sea
print(f"El salario neto a pagar es de: {salario}")

#calcular aumento de acuerdo a una categoria obrera
tipo_obrero = input("Favor indicar el tipo de obrero por categoría A, B o C:  ") 
if tipo_obrero == "Categoria A":
    aumento= salario*0.3
elif tipo_obrero == "Categoria B":                       
    aumento = salario*0.2
elif tipo_obrero == "Categoria C":
    aumento = salario*0.1       

salarioTotal = salario + aumento
print (f"El aumento que le corresponde en colones es de: {aumento}")
print(f"El nuevo salario de acuerdo al tipo de obrero es de: {salarioTotal}")

#Calcule un aumento del 25%
#aumento = salario*0.25
#print(f"Lo que equivale al aumento de su salario en colones es de: {aumento}")
#Calcule el total de salario a pagar con el aumento del 25%
#salarioTotal = salario + aumento
#Calcule el salario total con un aumento del 25%
#print(f"El salario total a pagar con descuento por semana es de: {salarioTotal}")


