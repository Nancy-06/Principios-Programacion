numero = 0
suma_total = 0

numero = int(input("Por favor ingrese un número: "))


while (suma_total < 1000):
    numero = int(input("Por favor ingrese un número: "))
    suma_total += numero

print ("El valor total de la suma es: ", suma_total)   