numero_secreto = 0
numero = 0
cant_intentos = 0

numero_secreto = int(input("Por favor ingrese el número secreto: "))
while (numero != numero_secreto):
    numero = int(input("Ingrese un número: "))
    if (numero == numero_secreto):
        print("Número correcto")
    else:
        if(numero > numero_secreto):
            print("Digite un número menor")
        else:
            print("Digite un número mayor")
    cant_intentos +=1
print ("Total de intentos realizados: ",cant_intentos)       
