#Declaracion de variables
salario = 0.0
salario_pend = 0.0
vacaciones_no_gozadas = 0.0
aguinaldo_prop = 0.0
preaviso = 0.0
cesantia = 0.0
liquidacion: 0.0

 #Leer salario_pend

salario = float(input("Ingrese su salario: "))
salario_pend = salario
vacaciones_no_gozadas = salario / 30 * 14
aguinaldo_prop = salario/ 12
preaviso = salario
cesantia = salario / 30 * 20 * 2
liquidacion = salario_pend + vacaciones_no_gozadas + aguinaldo_prop + preaviso + cesantia



print ("El total de su liquidacion es de:  ", liquidacion)


