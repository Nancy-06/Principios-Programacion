def imprimirfallos(fallos): #Rutina creada
    if fallos == 0:
        print("  _________     ")
        print(" |/        |    ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 1:
        print("  _________   ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 2:
        print("  _________     ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |         |    ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 3:
        print("  _________     ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |         |\   ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 4:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 5:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |         |    ")
        print(" |              ")
        print(" |              ")
    elif fallos == 6:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |         |    ")
        print(" |        /     ")
        print(" |              ")
        print(" |              ")
    else:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |         |    ")
        print(" |        / \   ")
        print(" |              ")
        print(" |              ")
        
                # Definición de rutinas
# rutina para verificar si la palabra es válida
def esPalabraValida(palabra):
    """
    Función que verifica si una palabra es válida según las condiciones dadas.
    """
     # Verifica si la palabra tiene más de 7 caracteres
    if len(palabra) <= 7:                                           #len para devolver el numero de elementos que contiene esa palabra
        return False                                   
    # Verifica si la palabra inicia con una vocal en minúscula                       
    vocales = ["a", "e", "i", "o", "u"]
    if palabra[0] in vocales and palabra[0].islower():              #islower() es un método en Python que se utiliza para verificar si todos los caracteres de una cadena están en minúsculas. Si la cadena contiene al menos un carácter en mayúscula o algún carácter que no es una letra, entonces este método devuelve False.
        return False
     # Verifica si la cantidad de vocales es inferior a la cantidad de consonantes
    vocales = 0
    consonantes = 0
    for letra in palabra:
        if letra in vocales:
            vocales += 1
        else:
            consonantes += 1
    if vocales >= consonantes:
        return False
    
    return True

# rutina para imprimir bienvenida 
def imprimirBienvenida(palabra):
    """
    Función que imprime un mensaje de bienvenida al juego y los guiones bajos para
    cada letra de la palabra.
    """
    print("\n" * 10)
    print("Ahorcado 3000Plus\n")
    print("_ " * len(palabra))

# rutina para imprimir mensaje de victoria
def imprimirGanaJuego():
    print("Has ganado el juego. :)")

# rutina para imprimir mensaje de derrota
def imprimirPierdeJuego():
    print("Has perdido, puedes intentarlo de nuevo.")



# Programa
palabra_secret = input("Ingresar su palabra secreta: ")
while not esPalabraValida(palabra_secret):
    print("Palabra ingresada no cumple las características requeridas, favor ingrsar otra:")




