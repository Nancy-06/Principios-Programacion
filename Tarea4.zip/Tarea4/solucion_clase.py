def es_palabra_valida(palabra : str ) -> bool:

    if len(palabra) <= 7:
        return False
    
    if palabra[0] in 'aeiou':
        return False
    
    if contar_vocales(palabra) >= contar_consonantes(palabra):
        return False

    return True
    
def valida_gane(palabra : str, letras_adivinadas : str ):

    for letra in palabra:
        if letra not in letras_adivinadas:
            return False

    return True

def contar_vocales(palabra : str):
    cantidad = 0

    for letra in palabra.lower():
        if(letra in 'aeiou'):
            cantidad += 1
    
    return cantidad


def contar_consonantes(palabra : str):
    cantidad = 0

    for letra in palabra.lower():
        if(letra not in 'aeiou'):
            cantidad += 1
    
    return cantidad

def imprimir_bienvenida( palabra : str ):
    print('          Bienvenido al ahorcado: ', '_' * len(palabra))


def imprimir_gana_juego():
    print('Usted ha ganado')


def imprimir_pierde_juego():
    print('Usted ha perdido')


def imprimir_palabra_turno(palabra_secreta : str , letras_adivinadas : str):
    palabra_imprimir = ''

    for letra in palabra_secreta:
       if letra in letras_adivinadas:
           palabra_imprimir += letra
       else:
           palabra_imprimir += '_'

    print(palabra_imprimir)


def imprimir_horca():
    print('''
          +---+
          |   |
              |
              |
              |
              |
        =========\n''')
    

def imprimirPierde1Intento():
    print('''
          +---+
          |   |
          o   |
              |
              |
              |
        =========\n''')


def imprimirPierde2Intento():
    print('''
          +---+
          |   |
          o   |
          |   |
              |
              |
        =========\n''')
    

def imprimirPierde3Intento():
    print('''
          +---+
          |   |
          o   |
         /|   |
              |
              |
        =========\n''')


def imprimirPierde4Intento():
    print('''
          +---+
          |   |
          o   |
         /|\  |
              |
              |
        =========\n''')
            

def imprimirPierde5Intento():
    print('''
          +---+
          |   |
          o   |
         /|\  |
          |   |
              |
        =========\n''')


def imprimirPierde6Intento():
    print('''
          +---+
          |   |
          o   |
         /|\  |
          |   |
         /    |
        =========\n''')
    

def imprimirPierde7Intento():
    print('''
          +---+
          |   |
          o   |
         /|\  |
          |   |
         / \  |
        =========\n''')
    
    def capturar_letra():

        letra = input('Ingrese un caracter: ')

    while not letra.isalpha():
        letra = input('Ingrese un caracter: ')
    
    return letra


def game( palabra : str ):

    contador = 0
    letras_adivinadas = ''

    while contador <= 7:
        letra = capturar_letra()       

        if letra in palabra and letra not in letras_adivinadas:
            letras_adivinadas += letra
            imprimir_palabra_turno(palabra, letras_adivinadas)
    
            if valida_gane(palabra, letras_adivinadas):
                imprimir_gana_juego()
                break

        else:
            contador += 1
            match contador:
                case 1:
                    imprimirPierde1Intento()

                case 2:
                    imprimirPierde2Intento()

                case 3:
                    imprimirPierde3Intento()

                case 4:
                    imprimirPierde4Intento()

                case 5:
                    imprimirPierde5Intento()
                    
                case 6:
                    imprimirPierde6Intento()

                case 7:
                    imprimirPierde7Intento()
                    imprimir_pierde_juego()
                    break       
            imprimir_palabra_turno(palabra, letras_adivinadas)

def main():

    palabra = input('Ingrese una palabra secreta: ')

    while not es_palabra_valida(palabra):
        palabra = input('Ingrese una palabra secreta válida: ')
    
    imprimir_bienvenida(palabra)
    imprimir_horca()

    game(palabra)


if _name_ == '_main_':
    main()