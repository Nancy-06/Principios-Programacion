def imprimirfallos(fallos): #Rutina creada
    if fallos == 0:
        print("  _________     ")
        print(" |/        |    ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 1:
        print("  _________   ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 2:
        print("  _________     ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |         |    ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 3:
        print("  _________     ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |         |\   ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 4:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |              ")
        print(" |              ")
        print(" |              ")
    elif fallos == 5:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |         |    ")
        print(" |              ")
        print(" |              ")
    elif fallos == 6:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |         |    ")
        print(" |        /     ")
        print(" |              ")
        print(" |              ")
    else:
        print("  __________    ")
        print(" |/        |    ")
        print(" |         O    ")
        print(" |        /|\   ")
        print(" |         |    ")
        print(" |        / \   ")
        print(" |              ")
        print(" |              ")
        
def imprimirBienvenida(palabra):
    print("\n" * 10)
    print("Bienvenido al juego Ahorcado 3000Plus\n")
    print("_ " * len(palabra))


def imprimirGanaJuego():
    print("Has ganado el juego. :)")


def imprimirPierdeJuego():
    print("Has perdido :( puedes intentarlo de nuevo.")


def esPalabraValida(palabra):
     
    if len(palabra) <= 7:                                           
        return False                                   
                          
    vocales = ["a", "e", "i", "o", "u"]
    if palabra[0] in vocales and palabra[0].islower():              
        return False

    cant_vocales = 0
    cant_consonantes = 0
    for letra in palabra:
        if letra in vocales:
            cant_vocales += 1
        else:
            cant_consonantes += 1
    if cant_vocales >= cant_consonantes:
        return False
    
    return True


palabra_secret = input("Ingresar su palabra secreta: ")
while not esPalabraValida(palabra_secret):
    print("Palabra ingresada no cumple las características requeridas, favor ingresar otra:")
    palabra_secret = input("Ingresar una palabra secreta: ")
imprimirBienvenida(palabra_secret)   

adivinada = len(palabra_secret) * ["_"]
fallos = 0
intentadas = ""

imprimirfallos(fallos)

while fallos < 7 and "_" in adivinada:
    letraIntentada = input("Ingrese intento de letra: ").lower()
    if letraIntentada in intentadas:
        print("Ya usted ha intentado con esta letra anteriormente")
    else:
        intentadas += letraIntentada+", "  
        if letraIntentada in palabra_secret.lower():
            for i in range(len(palabra_secret)):
                if palabra_secret [i].lower() == letraIntentada:
                    adivinada[i] = palabra_secret[i]
            print(adivinada)
        else:
            fallos += 1
            imprimirfallos(fallos)
    print("Letras intentadas: ",intentadas) 
if "_" not in adivinada:
    imprimirGanaJuego()
else:
    imprimirPierdeJuego()
    print("La palabra secreta es: ",palabra_secret)               