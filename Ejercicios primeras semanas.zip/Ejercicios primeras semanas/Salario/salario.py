horas_trabajadas = 0
precio_hora = 0.0
salario = 0.0
fraccion_horas_regulares = 0.0
fraccion_horas = 0.0
fraccion_horas_extra = 0.0

horas_trabajadas = float ( input( "Ingrese el numero de horas trabajadas. "))
precio_hora = float (input("Ingrese el precio por hora: "))

if (horas_trabajdas > 40) :
    fraccion_horas_regulares = precio_hora * 40
    fraccion_horas_extra = (horas_trabajadas - 40) * precio_hora * 1.5
    salario = fraccion_horas_regulares + fraccion_horas_extra 

else :
    salario = horas_trabajadas * precio_hora

    print ("El salario por horas semanal de la persona es: ", salario)
    