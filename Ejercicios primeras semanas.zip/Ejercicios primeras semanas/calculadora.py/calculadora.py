# Utilizar IF, ELIF y Else
# Tambien realizar ejercicio con estructura match
# Validar que los digitos ingresados sean numéricos (bloque try)

num1 = 0
num2 = 0

print("/****************/")
print("/ Calculadora v 0.1 de 2 números             /")
print("/                                            /")
print("/ 1- Suma                                    /")
print("/ 2- Resta                                   /")
print("/ 3- Multiplicación                          /")
print("/ 4- División                                /")
print("/ 5- Salir                                   /")
print("/                                            /")
print("/****************/")
seleccion = input("Digite el número de la operación a realizar: ")

try:
    num1 = int(input("Ingrese el primer número: "))
except:
    print("Error")
try:
    num2 = int(input("Ingrese el segundo número: "))
except:
    print("Error")

if seleccion == "1":
    print("El resultado de la suma es: ", num1 + num2)
elif seleccion == "2":
    print("El resultado de la resta es:", num1 - num2)
elif seleccion == "3":
    print("El resultado de la multiplicación  es:", num1 * num2)
elif seleccion == "4":
    try:
     print("El resultado de la división es:", num1 / num2)
    except ZeroDivisionError:
        print("Usted está intentando dividir por cero")

elif seleccion == "5":
    print("Salir")
else:
    print("Usted ha seleccionado una opción inválida")
   

    



    

        
