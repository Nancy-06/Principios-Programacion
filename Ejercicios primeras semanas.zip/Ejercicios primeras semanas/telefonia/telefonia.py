nombre = ""
recarga = 0.0
annos = 0
recarga_total: 0.0

nombre = input("Ingrese su nombre: ")
recarga = float(input("Ingrese el monto de la recarga: "))
annos_servicio = int(input("Ingrese sus años de servicio:"))

if((recarga >= 2000 and recarga <= 3800) and (annos >= 1 and annos <= 3)):
    recarga += recarga * 2
    print ("Aplica promocion, su recarga total es de: " , recarga)

elif((annos >= 3 and annos <= 5) and (recarga >=3800 and recarga <= 5000)):
        recarga += recarga * 3
        print ("Aplica promocion, su recarga total es de: ", recarga)
elif(annos >= 5):
           recarga += recarga * 3
           print("Aplica promocion, su recarga total es de: ", recarga)
           
else:

    print("No aplica a la promocion")



            
        
        
   
    
    

    
             
