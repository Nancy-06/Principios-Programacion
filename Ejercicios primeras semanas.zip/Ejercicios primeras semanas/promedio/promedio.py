# Declaración de variables
nota1 = 0.0
nota2 = 0.0
nota3 = 0.0
cantidad = 3
sumatoria =  0.0
promedio = 0

nota1 = float(input("Ingrese la nota del examen 1: "))
nota2 = float(input("Ingrese la nota del examen 2: "))
nota3 = float(input("Ingrese la nota del examen 3: "))

sumatoria = nota1 + nota2 + nota3
promedio = sumatoria / cantidad

print("El promedio es: ", promedio)
