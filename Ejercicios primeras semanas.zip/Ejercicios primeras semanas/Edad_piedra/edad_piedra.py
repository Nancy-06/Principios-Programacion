edad_piedra = 0.0
era_geologica = ""

edad_piedra = float(input("Ingrese la edad de la piedra: "))


if edad_piedra < 65.5:
    print("La era geologica de la piedra es cenozoica")
elif edad_piedra < 251:
    print("La era geologica de la piedra es mesozoica")
elif edad_piedra < 542:
    print("La era geologica de la piedra es paleozoica")
elif edad_piedra >=542:
    print("La era geologica de la piedra es pre-paleozoica")
    
