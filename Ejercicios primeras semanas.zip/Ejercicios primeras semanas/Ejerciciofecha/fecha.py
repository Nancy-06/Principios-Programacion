dia = 14
mes = "febrero"
año = 2023

dia = int(input("Ingrese la fecha de hoy: "))
mes = input("Ingrese el mes: ")
año = int(input("Ingrese el año: "))

if ((dia < 15 or mes == "febrero") and (año == 2023)):
    print("La fecha de mañana es 15 de febrero del 2023")

    
    
