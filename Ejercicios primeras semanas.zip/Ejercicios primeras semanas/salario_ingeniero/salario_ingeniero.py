salario_base = 0.0
horas_extra = 0
codigo_ingeniero = 0
MAXIMO_HORAS_EXTRA = 30
monto_horas_extra = 0
salario_total = 0.0

print("----------------------------")
print("CÁLCULO DE SALARIO POR MES")
print("----------------------------")
print("1. Ingeniero Civil")
print("2. Ingeniero de Software")
print("3. Ingeniero Eléctrico")
print("4. Ingeniero Industrial")

codigo_ingeniero = int(input("Ingrese el codigo de ingeniero: ")) #entrada


if(codigo_ingeniero == 1):
    salario_base = 750000 #intermedia
    monto_horas_extra = 6250 #intermedia
elif(codigo_ingeniero ==2):
    salario_base = 1300000
    monto_horas_extra = 10800
elif(codigo_ingeniero ==3):
    salario_base = 675000
    monto_horas_extra = 5625
elif(codigo_ingeniero == 4):
    salario_base = 1150000
    monto_horas_extra = 0
else:
    salario_base = 0
    monto_horas_extra = 0

if(salario_base != 0):
    if(codigo_ingeniero <= 3):
        horas_extra = int(input("Ingrese la cantidad de horas extras trabajadas: ")) #entrada
        if(horas_extra <= MAXIMO_HORAS_EXTRA):#constante
            salario_total = salario_base + (horas_extra + monto_horas_extra)
        else:
            salario_total = salario_base + (MAXIMO_HORAS_EXTRA * monto_horas_extra)
    else:
     salario_total = salario_base
    print(f'>> El salario total del ingeniero es de: {salario_total} colones.\n')
else:
 print('>> Error al calcular el salario. Por favor verifique el codigo de ingeniero.\n') 


