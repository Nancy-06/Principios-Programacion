#Haga una función que, dado dos lados de un triángulo, calcule y retome la hipotenusa. Pruebe su función en un
#programa. Recuerde que: Hipotenusa = Raiz cuadrada de lado1** 2 + lado 2**2

import math
hipotenusa = 0.0
lado_1 = 0.0
lado_2 = 0.0

lado_1 = float(input("Ingrese medida del lado 1 del triangulo: "))
lado_2 = float(input("Ingrese medida del lado 2 del triangulo: "))

def calc_hipotenusa(lado_1, lado_2): 
    """
    Función que calcula la hipotenusa.
    Recibe 2 lados de número tipo entero
    Retorna la hipotenusa en número flotante 
    """
      
    return math.sqrt(lado_1**2 + lado_2**2) #Teorema de pitagoras: el cuadrado de la hipotenusa sera la raiz cuadrada de cateto1**2 + cateto2**2
  
print("La longitud de la hipotenusa es: ",hipotenusa)

#def es la palabra que nos dice lo que viene a continuacion, es la función
#luego de def pongo lo que necesito hacer, osea calcular la hipotenusa
#luego entre () pongo lo que me dan para calcular, en este caso me dan lado 1 y lado 2 como referencia

#y otra forma más avanzada de hacer el (lado_1, lado_2) es agregandole el valor de los lados ahi mismo, quedaria asi:
#def calc_hipotenusa(lado_1: int, lado_2: int): #esto que para que cuando le de print lo imprima entero #esto es un bonus que puedo hacer, no necesario.

#cada vez que voy a importar una formula, en este caso math.sqrt que es para la raiz cuadrada, siempre
#voy a poner arriba el import math, luego entre parentesis pongo la funcion para sacar la hipotenusa
#para poner texto visible al usuario donde explica las formulas se usan 3 dobles comillas: """" y """" justo abajo de la otra.
#otra forma "más avanzada de hacer el print es: print(calc_hipotenusa)
# #antes de dar print le agrego los valores de los lados al print de esta forma:
#print(calc_hipotenusa(2, 4)) y ejecuto.
