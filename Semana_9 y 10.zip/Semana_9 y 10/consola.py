#Aplicación de consola que permite listar, agregar y eliminar tareas (Sin utilizar listas)
#Si el usuario presiona 1, en el menú de opciones, deberá ingresar una tarea
#Si el usuario presiona 2, en el menú de opciones, se visualizarán las tareas actuales
#Si el usuario presiona 3, en el menú de opciones, podrá eliminar una tarea
#Se ejecutará indefinidamente hasta que el usuario presione 4 en el menú de opciones para salir
#El sistema deberá mostrar un menú de bienvenida con las posibles acciones a realizar


# El sistema deberá mostrar un menú de bienvenida con las posibles acciones a realizar

def add_task(tasks : str):
    new_task = input('Ingrese la nueva tarea: ')

    if not tasks:
        tasks = new_task + '-'
    else:
        tasks += f'{new_task}' + '-'
    print(f'Tarea agregada: {new_task}')
    return tasks

def show_tasks(tasks : str):
    print('Lista de tareas')
    if tasks:
        print(tasks.replace('-', '\n'))


def delete_task(tasks : str):
    task_to_delete = input('Ingrese la tarea a eliminar: ')

    if task_to_delete in tasks:
        tasks = tasks.replace(f'{task_to_delete}-', '')
    else:
        print('La tarea no existe')

    return tasks


def show_menu():
    print('1- Agregar tarea')
    print('2- Mostrar tareas')
    print('3- Eliminar tarea')
    print('4- Salir')


#TODO: Leer una opción válida de selección
def read_input():
    pass


def main():
    
    tasks = ''
    while True:
        show_menu()
        selected = input("Ingrese la acción a realizar: ")
        if selected == '1':
            tasks = add_task(tasks)
        elif selected == '2':
            show_tasks(tasks)
        elif selected == '3':
            tasks = delete_task(tasks)
        elif selected == '4':
            break
        else:
            print('Ha ingresado una opción inválida')


if __name__ == '_main_':

    main()