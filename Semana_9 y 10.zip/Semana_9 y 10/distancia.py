#Haga una función que reciba una distancia en metros y calcule el equivalente en pies y otra función que recibe una
#distancia en metros y calcule el equivalente en pulgadas. Pruebe las dos funciones en un programa. Tenga en
#cuenta que:
#1 pie = 1 metro * 39,3701
#1 pulgada = 1 metro * 3,28084

def metros_pies(distancia_mtrs):        #metros_pies es lo que me piden calcular en la primera funcion.
    return distancia_mtrs * 3.28084     #distancia_metros es lo que recibo de referencia

def metros_pulgadas(distancia_mtrs):    #metros_pulgadas es lo que me piden calcular en la 2da funcion.
    return distancia_mtrs * 39.3701     ##distancia_metros es lo que recibo de referencia

print(metros_pies(1.90))                
print(metros_pulgadas(1.90))
