#Una empresa que fabrica juguetes para niños desea calcula cuánta madera necesita para construir juegos de
#piezas de armar que contengan cubos, esferas y cilindros. Haga un programa que, a partir del número de piezas de
#cada tipo y las dimensiones de cada tipo de pieza, calcule el volumen total de la madera que se necesita. Suponga
#que todos los cubos tienen la misma dimensión, todas las esferas son iguales y todos los cilindros también tienen la
#misma dimensión, además recuerde que:

#volumen de una esfera = 4 sobre 3 pi * radio**3
#volumen de un cubo = base * altura*ancho
#volumen de un cilindro = altura * pi * radio**2

#Para esto haga una función que calcule el volumen de una esfera, otra que calcule el volumen de un cubo y
#otra que calcule el volumen de un cilindro. El programa debe preguntar cuántas piezas debe construir de cada
#tipo y las dimensiones de cada tipo, y debe imprimir el total de madera que se necesita en total.

import math

num_piezas_cubo = 0
lado_cubo = 0
num_piezas_esfera = 0
radio_esfera = 0.0
num_piezas_cilindro = 0
altura_cilindro = 0.0
radio_cilindro = 0

num_piezas_cubos = int(input("Ingrese el número de cubos a construir: "))
lado_cubo = float(input("Ingrese la longitud del lado de cada cubo (en cm): "))

num_piezas_esferas = int(input("Ingrese el número de esferas a construir: "))
radio_esfera = float(input("Ingrese el radio de cada esfera (en cm): "))

num_piezas_cilindros = int(input("Ingrese el número de cilindros a construir: "))
altura_cilindro = float(input("Ingrese la altura de cada cilindro (en cm): "))
radio_cilindro = float(input("Ingrese el radio de cada cilindro (en cm): "))

def volumen_esfera(radio):
    return  (4/3) * math.pi * radio**3

def volumen_cubo(lado):
    return lado * lado * lado #lado**3

def volumen_cilindro(radio, altura):
    return altura * math.pi * radio**2

volumen_total_madera = num_piezas_esferas * volumen_esfera(radio_esfera) + num_piezas_cubos * volumen_cubo(lado_cubo) + num_piezas_cilindros * volumen_cilindro(radio_cilindro, altura_cilindro)

print("Se necesitan: ", volumen_total_madera, "cm de madera para construir los juegos de piezas")

#El programa comienza importando el módulo math, que utilizamos para calcular el volumen de una esfera y un cilindro. 
#Luego, definimos tres funciones volumen_esfera, volumen_cubo y volumen_cilindro que calculan el volumen de una esfera, un cubo y un cilindro, respectivamente. 
#Cada función toma como argumentos las dimensiones de la pieza (el radio, el lado o el radio y la altura, respectivamente) y devuelve el volumen correspondiente.
#A continuación, el programa pide al usuario el número de piezas a construir de cada tipo y las dimensiones de cada tipo. Estos valores se almacenan en variables correspondientes.
#Luego, se calcula el volumen total de la madera necesaria sumando el volumen de cada tipo de pieza multiplicado por la cantidad de piezas a construir. 
#Finalmente, se imprime el volumen total de madera necesario en la consola.