#Haga una función que reciba tres números enteros y retorne el mayor de ellos. Pruebe su función en un programa.

num_1 = 0
num_2 = 0
num_3 = 0

num_1= int(input("Ingrese el primer número entero: "))
num_2 = int(input("Ingrese el segundo número entero: "))      
num_3 = int(input("Ingrese el tercer número entero: "))   

def num_Mayor(num_1 ,num_2 ,num_3):
    mayor = num_1
    if num_2 > mayor:
        mayor = num_2
    elif num_3 > mayor:
        mayor = num_3

    return mayor

resultado = num_Mayor(num_1, num_2, num_3)

print("El número mayor es:", resultado)
           
 #La función recibe tres parámetros: num1, num2 y num3. Comienza asumiendo que num1 es el mayor de los tres y lo guarda en la variable mayor.#Luego, compara num2 con mayor y, si es mayor, actualiza el valor de mayor con num2.      
# Finalmente, compara num3 con mayor y, si es mayor, actualiza el valor de mayor con num3. Al final, retorna el valor de mayor.           
