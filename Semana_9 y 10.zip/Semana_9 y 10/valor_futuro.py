#Haga una función que calcule la cantidad de dinero que se tendría después de n años (a este valor se le llama valor
#future), a una tasa de interés I, teniendo p dinero hoy (a este valor se le llama valor presente). El valor futuro se
#calcula con la siguiente formula: valor futuro = p *(1+i)**n
import math
valor_futuro= 0     #cantidad de dinero 
i = 0.0             #(i) 
p = 0.0             #(p)
n = 0                #años

p = float(input("Ingrese el valor presente: "))
i = float(input("Tasa de interés: "))
n = int(input("Ingrese la cantidad de años: "))

def Valor_futuro(p, i, n): 
     valor_futuro = p*pow((1+i),n)
     return valor_futuro

print("El valor futuro es: ", valor_futuro)


