import os
from time import sleep

def mostrar_menu():
    print('Operaciones disponibles')
    print('1 - Suma')
    print('2 - Resta')
    print('3 - Multiplicación')
    print('4 - División')
    print('5 - Salir')


def valida_input(num_input, order):

    while not num_input.isnumeric():
        print('Ha ingresado un valor incorrecto. Por favor, ingrese un número')
        num_input = input(f'Ingrese el {order} número: ')
    
    return int(num_input)


num1 = 0
num2 = 0
opcion_seleccion = '1'

while opcion_seleccion != '5':

    mostrar_menu()

    opcion_seleccion = input("Ingrese el número de operación a realizar: ")

    if opcion_seleccion != '1' and opcion_seleccion != '2' and opcion_seleccion != '3' and opcion_seleccion != '4':
        if opcion_seleccion == '5':
            print('Finalizado')
            break
        else:
            print('Ha ingresado una opción incorrecta')
            continue 

    resultado = 0

    num1_input = input('Ingrese el primer número: ')

    num1 = valida_input(num1_input, 'primer')
    
    num2_input = input('Ingrese el segundo número: ')

    num2 = valida_input(num2_input, 'segundo')

    if opcion_seleccion == '1':
        resultado = num1 + num2
    elif opcion_seleccion == '2':
        resultado = num1 - num2
    elif opcion_seleccion == '3':
        resultado = num1 * num2
    elif opcion_seleccion == '4':
        if num2 == 0:
            print('No se puede dividir por cero')
            continue
        resultado = num1 / num2

    # print('El resultado es:', resultado)
    # print('El resultado es:' + str(resultado))
    print(f'El resultado es: {resultado}')
    sleep(2)
    os.system('cls')

print('Saludos')