import random

def imprimirMenu():
    print("\n---------Bienvenidos a Battleship!!!!---------\n")
    print("\n----------------------------------------------\n")
    print("Seleccione una opción:")
    print("1. Inicializar el juego")
    print("2. Imprimir posición de los barcos")
    print("3. Jugar")
    print("4. Salir")
    print("\n----------------------------------------------\n")


barcosJugador=[0]*20
barcosComputadora=[0]*20

def inicializarbarcosComputadora():
    for i in range(5):
        posicion = random.randint(0, 19)
        while barcosComputadora[posicion] != 0:
            posicion = random.randint(0, 19)
        barcosComputadora[posicion] = i+1


def inicializarbarcosJugador():
    for i in range(5):
        posicion = int(input("Ingrese la posición del barco " + str(i+1) + ": "))
        while barcosJugador[posicion - 1] != 0:
            posicion = int(input("Esta posición está ocupada, ingrese otra posición: "))
        barcosJugador[posicion] = i+1


def imprimirBarcos(jugador):
  if jugador:
    lista = barcosJugador
    print("Sus barcos:")
  else:
    lista = barcosComputadora
    print("Barcos de la computadora:")
  for i in range(0, 20, 5):
    print(lista[i:i+5])
 

def hacerDisparo(lista, posicion):
  if lista[posicion] != 0:
    barco = lista[posicion]
    lista[posicion] = 0
    return barco
  else:
    return -1


def imprimirGanador(jugadorDerribados, computadoraDerribados, jugadorSuma, computadoraSuma):
  if jugadorDerribados == 5:
    print("Felicidades, ganaste!:)")
  elif computadoraDerribados == 5:
     print("La computadora ha ganado.")
  elif jugadorDerribados == computadoraDerribados:
    if jugadorSuma > computadoraSuma:
       print("Felicidades, ganaste!:)")
    elif jugadorSuma < computadoraSuma:
      print("La computadora ha ganado.")
    else:
      print("Ha habido un empate!")
  elif jugadorDerribados > computadoraDerribados:
    print("Felicidades, ganaste!:)")
  else:
    print("La computadora ha ganado.")


opcion = 0
while opcion != 4:
  imprimirMenu()
  opcion = int(input("Escoja una opción: "))
  
  if opcion == 1:
    inicializarbarcosComputadora()
    inicializarbarcosJugador()
  
  elif opcion == 2:
    imprimirBarcos(True)
    imprimirBarcos(False)
  
  elif opcion == 3:
    jugadorDerribados = 0
    computadoraDerribados = 0
    jugadorSuma = 0
    computadoraSuma = 0

    for i in range(10):
      print(f"Intento {i+1}:")
      posicion = int(input("Ingrese una posición: "))
      while posicion < 0 or posicion > 19:
        posicion = int(input("Posición no válida, ingresa otra: "))
      derribado = hacerDisparo(barcosComputadora, posicion)
      if derribado != -1:
        print("¡Has derribado un barco!")
        jugadorDerribados += 1
        jugadorSuma += derribado
      else:
        print("Intento fallido.")
      
      posicion = random.randint(0, 19)
      while barcosJugador[posicion] == 0:
        posicion = random.randint(0, 19)
      derribado = hacerDisparo(barcosJugador, posicion)
      if derribado != -1:
        print("La computadora ha derribado un barco.")
        computadoraDerribados += 1
        computadoraSuma += derribado
      else:
        print("La computadora ha fallado su intento.")

      if jugadorDerribados == 5 or computadoraDerribados == 5:
        break

    imprimirGanador(jugadorDerribados, computadoraDerribados, jugadorSuma, computadoraSuma)
  
  elif opcion == 4:
    print("Gracias por jugar.")
  
  else:
    print("Opción no válida. Inténtelo de nuevo.")





