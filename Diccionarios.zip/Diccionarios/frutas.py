"""
Haga un algoritmo que solicite la cantidad de frutas de cada tipo que hay en un supermercado, 
se debe solicitar a un usuario que ingrese el tipo de fruta y su cantidad.

Haga un menú que realice lo siguiente:

1.Calcule la cantidad total de frutas registradas
2.Imprima la cantidad de frutas de cada tipo.
4.Imprima el número total de frutas del supermercado.
"""
#se hace primero el menu

menuFrutas="MENU FRUTAS\n\n"
menuFrutas+="1.Cantidad de frutas por tipo a consultar\n"
menuFrutas+="2.Tipos de frutas\n"
menuFrutas+="3.Total de frutas del supermercado\n"
menuFrutas+="4.Registro completo\n"
menuFrutas+="5.Salir\n"
menuFrutas+="Opción:"

#empiezo por calcular la cantidad de frutas del supermercado
#creo una diccionario frutas para que se guarde cada fruta

diccionarioFrutas={}
#pedimos el dato, uso un while porque no se sabe cuantas frutas se van a pedir
#creo una variable de ingreso para que la primera vez ingrese al menu
solicitaIngreso="si"


suma=0
cod=0
while(cod!=5):
    cod=int(input(menuFrutas))
    if (cod==1):
        print("Cantidad de frutas por tipo: ") #esto es imprimir dicionario clave y valor ocupo 
        tipoFruta=input("Ingrese la fruta a consultar: ").lower()
        if (tipoFruta in diccionarioFrutas):
            print(f"La cantidad de frutas para {tipoFruta} es {diccionarioFrutas.get(tipoFruta)}")
        else:
            print(f"Lo sentimos, la fruta {tipoFruta} no se encuentra en bodega.")
    #ahora ocupo imprimar tipod de frutas
    elif (cod==2): 
        print("\nTipos de frutas: ")
        for clave in diccionarioFrutas:
            print(clave)
    #ahora ocupo la sumatoria de frutas del supermercado, necesito recorrer el diccionario       
    elif (cod==3):
        for clave in diccionarioFrutas:
            suma+=diccionarioFrutas.get(clave)

        print(f"La cantidad de frutas es: {suma}")       
    elif (cod==4):
        for clave in diccionarioFrutas:
            print(f"{clave} - {diccionarioFrutas.get(clave)}\n")
    else:
        print("El código no existe, veifique nuevamente")
    print()            


print("Salió")
  







