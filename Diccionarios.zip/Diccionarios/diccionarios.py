#Hacer una lista de personas:
lista1=["116030849","Cristian",20,"Ingeniero"] #el 116030849 es la cedula, el 20 es la edad, ingeniero la profesion
lista2=["119058763","Juan",30,"Abogado"]

diccionarioPersonas={"116030849":lista1, "119058763":lista2}

print(diccionarioPersonas)

#Otra lista:
diccionarioNombres= {111: "Goku Andres", 112:"Laura Palmer", 113: "Carlos Andres"}
print(diccionarioNombres)

#para recorrer diccionarioNombres uso:

for k,v in diccionarioNombres.items():   #k es la clave y v el valor
    print(k," - ",v)

#para encontrar elementos por medio de su clave:

key=111
if(key in diccionarioNombres):
	print(f"La clave {key} si existe en el diccionario")
else:
    print(f"La clave {key} no existe en el diccionario")
