puntos_infracciones = 0
monto_total = 0.0
pago_bcr = ""
annos_vigencia = 0

requisitos = "Los requisitos necesarios para la renovacion de la licencia son los siguientes:\n-Tener documento de identificacion al dia y en buen estado\n-Tener vigente el examen medico digital para licencia\n-Pagar todas las multas de transito que tenga pendientes\n-No haber llegado a los 12 puntos acumulados por infracciones de transito, se les suspende la licencia y no puede hacer renovacion."
print(requisitos)

puntos_infracciones = int(input("Ingrese los puntos por infracciones: "))
pago_bcr = input("Favor indicar si el tramite lo esta realizando por medio del bcr: ")

#requisitos para renovar licencia

if pago_bcr == "si":
   cargo_bcr = 4200
else: 
   cargo_bcr = 0
     
if puntos_infracciones >= 12:
    print("Se suspende la licencia y no puede hacer renovacion")
elif puntos_infracciones < 4:
    monto_total = 5000 + cargo_bcr
    annos_vigencia = 6
    print("Usted tiene la licencia vigente y el monto total a cancelar es de: ", monto_total, "y los años de vigencia de la nueva licencia son de: ", annos_vigencia)

elif puntos_infracciones > 5 and puntos_infracciones < 8:
    monto_total = 10000 + cargo_bcr
    annos_vigencia = 4
    print("Usted tiene la licencia vigente y el monto total a cancelar es de: ", monto_total, "y los años de vigencia de la nueva licencia son de: ", annos_vigencia)
elif puntos_infracciones > 9 and puntos_infracciones < 11:
     monto_total = 10000 + cargo_bcr
     annos_vigencia = 3
     print("Usted tiene la licencia vigente y el monto total a cancelar es de: ", monto_total, "y los años de vigencia de la nueva licencia son de: ", annos_vigencia)
    
        





