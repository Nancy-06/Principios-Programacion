for i in range(6, 1, -1):
    cantidad_vacias = 6 - i
    cantidad_llenas = i * 2 - 3
    print(" " * cantidad_vacias + "*" * cantidad_llenas)