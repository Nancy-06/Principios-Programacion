for i in range(1,6):
    print('*' * i)

for j in range(4, 0 ,-1):
    print('*' * j)
