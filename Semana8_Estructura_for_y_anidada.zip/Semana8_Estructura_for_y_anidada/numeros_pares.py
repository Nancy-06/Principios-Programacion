#Haga un programa que imprima todos los números pares desde 1 hasta N, donde N es un númeroentero positivo. Ejemplo: si N=10, el programa imprime lo siguiente:
#2
#4
#6
#8
#10




numero = 10
for numero in range(2, 11, 2):  #el primer 2 es donde inicia, el 11 es el limite porque o si no no imprime el 10, el ultimo 2 quiere decir el orden que quiero que lleve, osea de dos en dos
    print(numero)

#for i in range(2, numero + 1):
#    if i % 2 == 0:
#       print (i) 

