#"En una empresa de venta de productos tecnológicos se tienen N cantidad de sucursales, se requiere
#saber cuánta es la cantidad de ventas a la semana de cada sucursal con su nombre, así como el total
#generado por la empresa. Considere que se trabajan 6 días a la semana y todos los días el monto de las
#ventas es diferente"

ventas_empresas = 0
cant_dias = 6
cant_sucursales = int(input('Ingrese la cantidad de sucursales existentes: '))
for i in range(cant_sucursales):
    nombre = input("Ingrese el nombre de la sucursal: ")
    ventas_semana = 0
    for j in range(cant_dias):
        ventas_por_dia =  int(input(f'Ingrese las ventas para el día {j + 1} : '))
        ventas_semana += ventas_por_dia
        ventas_empresas += ventas_semana
        print("Las ventas semanales de la sucursal: ",nombre, "fueron de",ventas_semana)

print("Las ventas semanales de la empresa fueron de: ", ventas_empresas )

