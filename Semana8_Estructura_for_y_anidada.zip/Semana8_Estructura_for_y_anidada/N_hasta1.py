#Haga un programa que dado un número entero N, imprima todos los números desde N hasta 1.
#Ejemplo: si N=4, el programa imprime lo siguiente: 
#4
#3
#2
#1


numero = 4
for numero in range(numero, 0, -1): #el numero es 4 donde inicia, el 0 es el limite porque si no no imprime el 1 y el -1 es que quiero que vaya descontando un numero en reversa
    print(numero)
