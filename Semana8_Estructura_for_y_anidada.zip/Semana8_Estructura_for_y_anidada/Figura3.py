for i in range(1, 6):
    cantidad_vacias = (6 - i) - 1
    cantidad_llenas = i * 2 - 1
    print(" " * cantidad_vacias + "*" * cantidad_llenas)