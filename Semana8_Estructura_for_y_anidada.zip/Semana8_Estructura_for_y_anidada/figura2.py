for i in range(6):
    cantidad_vacias = 6 - (i + 1)
    cantidad_llenas = i + 1
    print(" " * cantidad_vacias + "*" * cantidad_llenas)