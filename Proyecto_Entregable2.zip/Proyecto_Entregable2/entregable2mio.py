#Haga un programa que lea el nombre de un equipo, el número de juegos ejecutados por el equipo 
#y la información correspondiente a cada uno de los juegos, e imprima un reporte de resultados de 
#todos los juegos del equipo, así como el puntaje total de los partidos, obtenido por el equipo. Para 
#cada uno de los juegos se debe preguntar el nombre del equipo oponente, el marcador de cada 
#uno, así como quién atrapó la snitch. El equipo que atrapó la snitch debe aparecer con un * 
#(asterisco) indicado en el marcador correspondiente, en el reporte de resultados.

#declaracion de variables
nombre_equipo = ""
num_juegos = 0
equipo_oponente = ""
marcador_1 = 0
marcador_2 = 0
snitch_1 = ""
snitch_2 = ""
puntaje_total = 0
resultados = ""

nombre_equipo = input("Equipo: ")
num_juegos = int(input("Número de juegos: "))

i = 1
while i <= num_juegos:
    equipo_oponente = input(f"Juego {i} contra: ")
    marcador_1 = int(input(f"Marcador de {nombre_equipo}: "))
    puntaje_total += marcador_1
    snitch_1 = input(f"Atrapó la snitch? (si/no): ") #indique si o no
    marcador_2 = int(input(f"Marcador de {equipo_oponente}: "))
    snitch_2 = input(f"Atrapó la snitch? (si/no): ") #indique si o no
   
    #se atrapó snitch si o no
    if snitch_1 == "si":
        marcador_1 = str(marcador_1) + "*"
    if snitch_2 == "si":
        marcador_2 = str(marcador_2) + "*"

    #Resultados del juego 
    linea_resultados = f"{nombre_equipo} vs {equipo_oponente} {marcador_1}-{marcador_2}\n"
    resultados += linea_resultados

    i+=1 
    
print("\n--------Reporte de resultados del partido---------")
print(resultados)  
print(f"El puntaje total de partidos de {nombre_equipo} es: {puntaje_total}")