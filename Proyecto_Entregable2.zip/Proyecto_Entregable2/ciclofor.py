# Inicializacion variables
puntaje_total = 0
resultados = ""
nombre_equipo = ""
num_juegos = 0
equipo_oponente = ""
marcador_1 = 0
marcador_2 = 0
snitch_1 = ""
snitch_2 = ""

nombre_equipo = input("Equipo: ")
num_juegos = int(input("Número de juegos: "))

# Iteracion
for i in range(1, num_juegos+1):
    equipo_oponente = input(f"Juego {i} contra: ")
    marcador_1 = int(input(f"Marcador de {nombre_equipo}: "))
    puntaje_total += marcador_1
    snitch_1 = input("Atrapó la snitch? (si/no): ")
    marcador_2 = int(input(f"Marcador de {equipo_oponente}: "))
    snitch_2 = input("Atrapó la snitch? (si/no): ")

    #se atrapó snitch si o no
    if snitch_1 == "si":
        marcador_1 = str(marcador_1) + "*"
    if snitch_2 == "si":
        marcador_2 = str(marcador_2) + "*"

    #Resultados del juego
    linea_resultados = f"{nombre_equipo} vs {equipo_oponente} {marcador_1}-{marcador_2}\n"
    resultados+=linea_resultados

print("\n--------Reporte de resultados del partido---------")
print(resultados)
print(f"El puntaje total de partidos de {nombre_equipo} es: {puntaje_total}")