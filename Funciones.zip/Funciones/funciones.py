
#acá me va a retornar el valor segun lo que yo quiera, el primer print va a tirar
#5 veces PythonPythonPythonPythonPython porque el primer print es de cad que es Python
#multiplicado por v que abajo le pusimos 5, tons imprime 5 veces python
#el segundo print va a tirar: HolaHolaHolaHolaHola, AdiosAdiosAdiosAdiosAdios, NNNNN
#porque el 2do print equivale a la cadena luego de *algomas(que viene siendo una tupla),
#agarra todo lo despues del 5 porque en los parametros solo puse 2 vaLores iniciales
#y lo multiplica por el v que abajo le puse 5 entonces imprime la cadena 5 veces 
#cada palabra

#def miFuncion(cad,v=2,*algomas):
    #print (cad*v)
    #for cadena in algomas:
    #    print (cadena*v)


#miFuncion('Python',5, 'Hola', 'Adios', 'N', 'Cadenas')      

#si le agrego un asterisco más al algo más asi: **algomas quiero decir que es un diccionario
#conteniendo los elementos que envié de más

#def miFuncion(cad,v=2,**algomas):
   # print (cad*v)
   # print (algomas['cadenaextra'])
  #  print (algomas['cadenademas'])

#miFuncion('Python',5, cadenaextra='Hola', cadenademas='Adios')  #le agrego mi clave al diccionario, cadena extra es la clave que le estoy añadiendo

#para regresar un valor

#def miFuncion(num1,num2):
#    return (num1+num2)
#resultado_suma = miFuncion(3,4)
#print (resultado_suma)

def resta(a,b):
    return a-b
    
c= resta(10,6)
print (c) #o print(f"La resta es: {resta}")
