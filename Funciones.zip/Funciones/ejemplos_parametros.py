#def mensaje():
   # print("Bienvenido Axell") #sin imprimo el sistema no tira nada porque tengo que llamar la funcion

def mensaje():
    print("Bienvenido Axell")

mensaje()     #aqui si imprime el msj

#def mensaje2(nombre):
    #print("Bienvenido", nombre)

#mensaje2()    #me da error porque necesito un parametro 

def mensaje2(nombre):  #nombre=cadena
    print("Bienvenido", nombre)
cadena=input("Ingrese su nombre: ")
mensaje2(cadena)      #cadena=nombre

def mensaje3(nombre):     #funcion que retorna #nombre=nom
    cadena="Bienvenido" + nombre     #se crea una variable cadena
    return cadena

nom=input("Ingrese su nombre: ")   #'Axell'  
cadenaRetorno=mensaje3(nom)             #si quiero llamar esta funcion debo guardarla en una variable 
print(cadenaRetorno)



    