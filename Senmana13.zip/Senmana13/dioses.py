#Realice una rutina que imprima la información de todos los dioses
dioses = ['Zeus', 'Hera', 'Poseidón', 'Dionisio', 'Apolo', 'Artemisa', 'Hermes','Atenea', 'Ares']
generos =  ['Masculino', 'Femenino', 'Masculino', 'Masculino','Masculino','Femenino', 'Masculino', 'Femenino', 'Masculino']
hijos = [26, 28, 16, 34, 14, 26, 38, 12, 9]


def rutinaimprimirDioses():
    for i in range(len(dioses)):
        print(f"{dioses[i]}:\nGenero: {generos[i]}\nCantidad de hijos: {hijos[i]}")
       

rutinaimprimirDioses() 

#Realice una rutina que reciba el sexo de un dios e indique cuántos dioses con ese sexo existen dentro de la lista

#def rutinaGenero(sexo):
    # Inicializamos un contador para llevar la cuen
    #contador = 0
    # Iteramos sobre los géneros de los dioses
    #for i in range(len(generos)):
        # Si el género del dios coincide con el sexo buscado, incrementamos el contador
        #if generos[i] == sexo:
            #contador += 1
    # Devolvemos el resultado
    #return contador
 
#sexo_dios = input("Ingrese el sexo del dios (Masculino/Femenino): ").capitalize()
#cantidad = rutinaGenero(sexo_dios)
#print(f"La cantidad de dioses con sexo {sexo_dios} es de: {cantidad}") 

#Realice un función que reciba el nombre de un dios, y lo busque dentro de la lista de dioses.
#Si el dios se encuentra retorna el índice(la posición en la que se encuentre)y si el dios no se encuentra en la lista retorna -1


def rutinabuscarDios(nombre_dios):
    if nombre_dios in dioses:
        posicion = dioses.index(nombre_dios)
        return posicion
    else:
        return -1

nombre = input("Ingrese el nombre del dios a buscar: ").capitalize()
posicion = rutinabuscarDios(nombre)
if posicion != -1:
    print(f"El dios '{nombre}' se encuentra en la lista de dioses en el índice {posicion}.")
else:
    print(-1)
