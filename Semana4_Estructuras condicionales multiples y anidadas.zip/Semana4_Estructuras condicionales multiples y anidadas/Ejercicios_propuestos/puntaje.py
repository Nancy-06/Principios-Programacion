#Se quiere saber la nota equivalente en letra a un puntaje dado. Si el puntaje es mayor o igual a 90 la nota es ‘A’, pero si el puntaje es mayor o igual a 80 la nota es ‘B’, si el puntaje es mayor o 
#igual a 70 la nota es ‘C’, y si el puntaje es menor que 70 la nota es ‘D’

nota = 0.0
puntaje = 0.0

puntaje = float(input('Ingrese el puntaje: '))
if (puntaje <= 90):
    nota = 'A'

elif (puntaje <= 80):    
    nota = 'B'

elif (puntaje <= 70):
    nota = 'C'

else:
    nota = 'D'

print(f'Usted obtuvo una nota de: ',nota)    

