compras_realizadas = 0
costo_total = 0
costo_final = 0

compras_realizadas = int(input('Digite la cantidad de compras realizadas por el cliente: '))
costo_total = float(input('Digite el costo total de la compra: '))

if (compras_realizadas >= 6 and costo_total >= 10000) :
#Se aplica el descuento del 35% sobre el costo total de la compra.
    costo_final = costo_total - (costo_total * 0.35)
else:
    costo_final = costo_total
print('El costo final de la compra es: ' , costo_final)
